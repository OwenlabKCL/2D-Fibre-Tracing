function [All_Averages,All_Averages_cellx,All_Averages_celly]=GetMovAve(Mat_x,Mat_y,Window, kf, kb)
Left_edges=round((Window-1)./2);
data=[Mat_x, Mat_y];
num_points=size(data);
Elements=1:1:size(data,1);
Elements=Elements';
Enclosed_elements= Elements(Left_edges+1:(size(Elements, 1)-Left_edges),:);
All_Averages=[];
if size(Enclosed_elements,1)~=0
        Start_enclosed=Enclosed_elements-kb;
        End_enclosed=Enclosed_elements+kf;
        Start_stop1=[Start_enclosed End_enclosed];
        XY_ave=[];
        for i=1:size(Enclosed_elements,1)
             XRange=Mat_x(Start_stop1(i,1):Start_stop1(i,2),:);
             YRange=Mat_y(Start_stop1(i,1):Start_stop1(i,2),:);
             x_ave=mean(XRange);
             y_ave=mean(YRange);
             XY_ave=[XY_ave; x_ave y_ave];
        end
        Free_start_elements=Elements(1:Left_edges,:);
        Free_end_elements=Elements((Enclosed_elements(end,1)+1:Elements(end,:)));
        S=size(Free_start_elements,1);
        Start_mat=data(1,:);
        End_mat=data(end, :);
        if S==1 %Window==3 case
           All_Averages=[Start_mat; XY_ave; End_mat];
           All_Averages=unique(All_Averages, 'rows','stable');
           All_Average_x=All_Averages(:,1);
           All_Average_y=All_Averages(:,2);
        end
        if S==2 %Window=5 case
            Second_start_element=Free_start_elements(2,1)-1;
            Second_end_element=Free_start_elements(2,1)+1;
            Start_stop2=[Second_start_element Second_end_element];

            XRange=Mat_x(Start_stop2(1,1):Start_stop2(1,2),:);
            YRange=Mat_y(Start_stop2(1,1):Start_stop2(1,2),:);
            x_ave=mean(XRange);
            y_ave=mean(YRange);
            new_ave=[x_ave y_ave];
            Second_start_element22=Free_end_elements(1,1)-1;
            Second_end_element22=Free_end_elements(1,1)+1;
            Start_stop22=[Second_start_element22 Second_end_element22];
            XRange2=Mat_x(Start_stop22(1,1):Start_stop22(1,2),:);
            YRange2=Mat_y(Start_stop22(1,1):Start_stop22(1,2),:);
            x_ave2=mean(XRange2);
            y_ave2=mean(YRange2);
            new_ave2=[x_ave2 y_ave2];
            All_Averages=[Start_mat; new_ave; XY_ave;new_ave2; End_mat];
            All_Averages=unique(All_Averages, 'rows','stable');
            All_Average_x=All_Averages(:,1);
            All_Average_y=All_Averages(:,2);
        end
        if S==4 %Window==9 case - 4Pt moving ave,
            Second_start_element=Free_start_elements(2,1)-1;
            Second_end_element=Free_start_elements(2,1)+1;
            Start_stop2=[Second_start_element Second_end_element];
            XRange=Mat_x(Start_stop2(1,1):Start_stop2(1,2),:);
            YRange=Mat_y(Start_stop2(1,1):Start_stop2(1,2),:);
            x_ave=mean(XRange);
            y_ave=mean(YRange);
            new_ave1=[x_ave y_ave];

            Second_start_element1=Free_start_elements(3,1)-2;
            Second_end_element1=Free_start_elements(3,1)+2;
            Start_stop3=[Second_start_element1 Second_end_element1];
            XRange1=Mat_x(Start_stop3(1,1):Start_stop3(1,2),:);
            YRange1=Mat_y(Start_stop3(1,1):Start_stop3(1,2),:);
            x_ave=mean(XRange1);
            y_ave=mean(YRange1);
            new_ave2=[x_ave y_ave];

            Second_start_element2=Free_start_elements(4,1)-3;
            Second_end_element2=Free_start_elements(4,1)+3;
            Start_stop4=[Second_start_element2 Second_end_element2];
            XRange2=Mat_x(Start_stop4(1,1):Start_stop4(1,2),:);
            YRange2=Mat_y(Start_stop4(1,1):Start_stop4(1,2),:);
            x_ave=mean(XRange2);
            y_ave=mean(YRange2);
            new_ave3=[x_ave y_ave];
            %%%%Now do the ends too..

            Third_start_element=Free_end_elements(1,1)-3;
            Third_end_element=Free_end_elements(1,1)+3;
            Start_stop_end1=[Third_start_element Third_end_element];
            XRange3=Mat_x(Start_stop_end1(1,1):Start_stop_end1(1,2),:);
            YRange3=Mat_y(Start_stop_end1(1,1):Start_stop_end1(1,2),:);
            x_ave2=mean(XRange3);
            y_ave2=mean(YRange3);
            new_ave4=[x_ave2 y_ave2];
            Third_start_element1=Free_end_elements(2,1)-2;
            Third_end_element1=Free_end_elements(2,1)+2;
            Start_stop_end2=[Third_start_element1 Third_end_element1];
            XRange4=Mat_x(Start_stop_end2(1,1):Start_stop_end2(1,2),:);
            YRange4=Mat_y(Start_stop_end2(1,1):Start_stop_end2(1,2),:);
            x_ave2=mean(XRange4);
            y_ave2=mean(YRange4);
            new_ave5=[x_ave2 y_ave2];
            Third_start_element2=Free_end_elements(3,1)-1;
            Third_end_element2=Free_end_elements(3,1)+1;
            Start_stop_end3=[Third_start_element2 Third_end_element2];
            XRange5=Mat_x(Start_stop_end3(1,1):Start_stop_end3(1,2),:);
            YRange5=Mat_y(Start_stop_end3(1,1):Start_stop_end3(1,2),:);
            x_ave2=mean(XRange5);
            y_ave2=mean(YRange5);
            new_ave6=[x_ave2 y_ave2];
            All_Averages=[Start_mat; new_ave1;new_ave2;new_ave3; XY_ave;new_ave4;new_ave5;new_ave6; End_mat];
                       All_Averages=unique(All_Averages, 'rows','stable');
            All_Average_x=All_Averages(:,1);
            All_Average_y=All_Averages(:,2);
        end   
else

         XY_ave=[]; R=[];XY_ave2=[]; XY_ave1=[];

            for i=1:size(Elements,1)
                 Read_in=Elements(i,1);
                if i==1
                    Read_behind=0;
                    Read_ahead=size(Elements, 1)-1;
                    x_ave=Mat_x(1,1);
                    y_ave=Mat_y(1,1);
                    XY_start=[x_ave, y_ave];
                end
                if i==size(Elements, 1)
                    Read_behind=i-1;
                    Read_ahead=0;
                    x_ave=Mat_x(end,1);
                    y_ave=Mat_y(end,1);
                    XY_end=[x_ave, y_ave];
                end
                    if i~=1 && i~=size(Elements, 1)
                        Read_behind=size(Elements(1:i,:),1)-1;
                        Read_ahead=size(Elements(i:end,:),1)-1;
                        if Read_behind<=Read_ahead
                            To_take_behind=Read_behind;
                            To_take_ahead=Read_behind;
                            Rows_to_take_below=i-To_take_behind;
                            Rows_to_take_above=i+To_take_ahead;
                            Xrange=Mat_x(Rows_to_take_below:Rows_to_take_above, :);
                            Yrange=Mat_y(Rows_to_take_below:Rows_to_take_above, :);
                            x_ave=mean(Xrange);
                            y_ave=mean(Yrange);
                            XY_ave1=[XY_ave1; x_ave y_ave];
                        end
                        if Read_behind>=Read_ahead
                            To_take_ahead=Read_ahead;
                            To_take_behind=Read_ahead;
                            Rows_to_take_behind=i-To_take_behind;
                            Rows_to_take_above=i+To_take_ahead;
                            Xrange2=Mat_x(Rows_to_take_behind:Rows_to_take_above, :);
                            Yrange2=Mat_y(Rows_to_take_behind:Rows_to_take_above, :);
                            x_ave2=mean(Xrange2);
                            y_ave2=mean(Yrange2);
                            XY_ave2=[XY_ave2; x_ave2 y_ave2];
                        end
                    end
 end

   
All_Averages=[XY_start; XY_ave1;XY_ave2;XY_end];
All_Averages=unique(All_Averages, 'rows','stable');
All_Average_x=All_Averages(:,1);
All_Average_y=All_Averages(:,2);
end 
All_Averages=unique(All_Averages,'rows','stable');
All_Averages=num2cell(All_Averages);
All_Averages_cellx={All_Average_x};
All_Averages_celly={All_Average_y};
end




     
        
        


