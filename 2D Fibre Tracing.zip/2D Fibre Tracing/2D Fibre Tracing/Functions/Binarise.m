%Get mesh areas.

function [H]=Binarise(P1, Ripley_radius,Figure)
Matrix=cell2mat(P1);
Region=importdata('Region.txt');
Min_x=min(Region(:,1)+Ripley_radius);
Max_x=max(Region(:,1)-Ripley_radius);
Min_y=min(Region(:,2)+Ripley_radius);
Max_y=max(Region(:,2)-Ripley_radius);
figure
for i=1:size(P1,1)
    hold on
    plot(P1{i,1},P1{i,2},'k')
end
if Figure==1
    foldername=['Fiber_map.fig'];
    savefig(foldername)
end
H=gcf;
ColourEventsBackground = [0 0 0]; 
AxisLimits = [Min_x Max_x Min_y Max_y];	
minX=AxisLimits(1);
maxX=AxisLimits(2);
minY=AxisLimits(3);
maxY=AxisLimits(4);
PlotWidth =  maxX - minX;
SaveHighDPI = strcat('-r',num2str(PlotWidth / 100)); 
BackgroundColour = [1 1 1];

H.Color=BackgroundColour;
H.Renderer='OpenGL';
H.Units='inches';
H.PaperUnits='inches';
H.PaperSize=[10 10];
H.PaperPositionMode='manual';
H.PaperPosition=[0 0 10 10];
H.Visible='on';
set(gca,'ydir','reverse')% Disable MATLAB's handy feature of totally ignoring your colouring when it does a 'print' operation.

H.CurrentAxes.DataAspectRatio=[1 1 1];
H.CurrentAxes.Color=BackgroundColour;
H.CurrentAxes.Visible='off';
H.CurrentAxes.Position=[0 0 1 1];
axis(AxisLimits);
axis square image tight
box('off');
set(H,'InvertHardcopy','off') 	
hold on % don't reset anything when plotting this next thing...
colormap('jet');
caxis([Min_x, Max_x]); 								
OutputName='Before_binarisation';
OutputFolder=pwd;
print(H,'-dtiff',SaveHighDPI,fullfile(OutputFolder,[OutputName,'.tiff']));
close
end