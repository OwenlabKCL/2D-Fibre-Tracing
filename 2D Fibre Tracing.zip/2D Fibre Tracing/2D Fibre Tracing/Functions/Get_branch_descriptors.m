%Input: Final_list:x, y, id, track, localisation
function [Filtered_branch_angles, Filtered_branch_coords,Number_of_branching_points]=Get_branch_descriptors(Output_PP,Size_ROI,Ripley_radius)

Mat_with_tracks_after_stitch=Output_PP; 
r_of_search=60;S=[];Start_end_points_full=[];
Matrix_to_accume=[];
 
for i=1:size(Mat_with_tracks_after_stitch,1)
   x_y_id=Mat_with_tracks_after_stitch(i,:);
   Matrix_x=[]; Matrix_y=[];Matrix_id=[];
   Matrix_to_sort=[];To_order=[]; 
   
   %Sort fibres by their orientations 
   for j=1:size(x_y_id, 1)                
     Matrix_x=x_y_id{j,1};
     Matrix_y=x_y_id{j,2};
     Matrix_id=x_y_id{j,3};
     Localisations=x_y_id{j,4};
     Tracks=x_y_id{j,5};
     Matrix_to_sort=[Matrix_x,Matrix_y,Matrix_id,Localisations,Tracks];
      To_order=Matrix_to_sort;
      
      [~, orientation] = max([std(To_order(:,1)),std(To_order(:,2))]);
          if orientation==1
               Matrix_sorted=sortrows(To_order, 1);
          elseif orientation==2
               Matrix_sorted=sortrows(To_order, 2);
          end
                       
  Matrix_sorted1=unique(Matrix_sorted, 'rows','stable');
  %Get start and terminating positions
  Fiber_start_x_full=Matrix_sorted1(1,1);
  Fiber_start_y_full=Matrix_sorted1(1,2);
  Fiber_end_x_full=Matrix_sorted1(end,1);
  Fiber_end_y_full=Matrix_sorted1(end, 2);
  Matrix_to_accume=[Matrix_to_accume;Matrix_sorted];
 end
 %All starting and terminating positions of detected fibres
 Start_end_points_full=[Start_end_points_full;Fiber_start_x_full , Fiber_start_y_full, Fiber_end_x_full,Fiber_end_y_full];           
end

x_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,1),[],@(v){v});
x_1(any(cellfun(@isempty,x_1),2),:) = [];
y_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,2),[],@(v){v});
y_1(any(cellfun(@isempty,y_1),2),:) = [];
id_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,3),[],@(v){v});
id_1(any(cellfun(@isempty,id_1),2),:) = [];
Loc_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,4),[],@(v){v});
Loc_1(any(cellfun(@isempty,Loc_1),2),:) = [];
Track_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,5),[],@(v){v});
Track_1(any(cellfun(@isempty,Track_1),2),:) = [];
%Fibre matrix with ordered orientations
Fibre_matrix=[x_1, y_1, id_1,Loc_1,Track_1];

%Re-initilise IDs to the column number to match the Start and End points 
%extracted
V_ID=[];
for e=1:size(Fibre_matrix,1)
    Vector_IDS=unique(cell2mat(Fibre_matrix(e,3)));
    V_ID=[V_ID; Vector_IDS];
end

Start_end_points_full(:,5)=V_ID;Matrix=cell2mat(Fibre_matrix);
xCoord=Matrix(:,1);yCoord=Matrix(:,2);NumberPoints=size(Matrix,1);
Fiber_id=unique(Matrix(:,3),'stable');
All_start_matrix=[];
All_possibilities=[];

%Start_points - search for possible branching fibres - if detected take angles
%and positions.... 

for d=1:size(Start_end_points_full,1)
    x_of_full_fiber=Fibre_matrix{d,1};
    y_of_full_fiber=Fibre_matrix{d,2};
    id_of_full_fiber=Fibre_matrix{d,3};
    
    Close_events=[];r_xCoord = [];r_yCoord = [];Id_coord=[];tDistances = [];
    x_start=Start_end_points_full(d,1);
    y_start=Start_end_points_full(d,2);
    id_start=Fiber_id(d,1);   
    
   %Creates bounding square for speed!
    xrow2=(Matrix(:,1)>=x_start-500) & (Matrix(:,1)<=x_start+500);
    output_x2 = Matrix(xrow2,:);
    yrow2=(output_x2(:,2)>=y_start-500) & (output_x2(:,2)<=y_start+500);
    Close_events= output_x2(yrow2,:);
    Number_points=size(Close_events, 1);
    
     for h = 1:Number_points
                if Close_events(h,3)~=d
                        xVar = Close_events(h,1);
                        yVar = Close_events(h,2);
                        IDVar=Close_events(h,3);
                        tDistance = sqrt ((xVar-x_start)^2 + (yVar-y_start)^2);
                    if tDistance < r_of_search
                        r_xCoord = [r_xCoord ; xVar];
                        r_yCoord = [r_yCoord ; yVar];
                        Id_coord=[Id_coord;IDVar];
                        tDistances = [tDistances ; tDistance]; 
                    end
                end   
     end 
     
     %Need to account for the case of no possible branching fibres     
     R_x_={};R_y_=[];Test_id=[];   
    if size(tDistances,1) == 0
        r_xCoord=x_of_full_fiber;r_yCoord=y_of_full_fiber;
        Id_coord=id_of_full_fiber;
        R_x_={r_xCoord};R_y_={r_yCoord};ID_coord_of_enclosed={Id_coord};
        ID_of_current_fiber=repmat(id_start, size(r_xCoord,1),1);
        ID_of_current_fiber1={ID_of_current_fiber};
        Test_id=[Test_id;ID_of_current_fiber1];
        All_possibilities=[R_x_,R_y_, Test_id, ID_coord_of_enclosed];
    elseif size(tDistances,1)~=0  
         R_x_={r_xCoord};R_y_={r_yCoord};ID_coord_of_enclosed={Id_coord};
         ID_of_current_fiber=repmat(id_start, size(r_xCoord,1),1);
         ID_of_current_fiber1={ID_of_current_fiber};
         Test_id=[Test_id;ID_of_current_fiber1];
         All_possibilities=[R_x_, R_y_,Test_id, ID_coord_of_enclosed];
    end
 All_start_matrix=[All_start_matrix;All_possibilities]; 
 %This matrix has x, y, ID of fibre and IDs of proximal fibres 
end
 
%Repeat for end points - search for possible branching fibres - if detected take angles
%and positions....  
All_end_matrix=[];All_possibilities=[];

for dd=1:size(Start_end_points_full,1)
    x_of_full_fiber=Fibre_matrix{dd,1};
    y_of_full_fiber=Fibre_matrix{dd,2};
    id_of_full_fiber=Fibre_matrix{dd,3};
    
    Close_events=[];r_xCoord = [];r_yCoord = [];Id_coord=[];tDistances = [];
    x_start=Start_end_points_full(dd,3);
    y_start=Start_end_points_full(dd,4);
    id_start=Fiber_id(dd,1);   
    
   %Creates bounding square for speed!
    xrow2=(Matrix(:,1)>=x_start-500) & (Matrix(:,1)<=x_start+500);
    output_x2 = Matrix(xrow2,:);
    yrow2=(output_x2(:,2)>=y_start-500) & (output_x2(:,2)<=y_start+500);
    Close_events= output_x2(yrow2,:);
    Number_points=size(Close_events, 1);
    
     for h = 1:Number_points
            if Close_events(h,3)~=d   
                xVar = Close_events(h,1);
                yVar = Close_events(h,2);
                IDVar=Close_events(h,3);
                tDistance = sqrt ((xVar-x_start)^2 + (yVar-y_start)^2);
                if tDistance < r_of_search
                    r_xCoord = [r_xCoord ; xVar];
                    r_yCoord = [r_yCoord ; yVar];
                    Id_coord=[Id_coord;IDVar];
                    tDistances = [tDistances ; tDistance]; 
                end
            end   
     end 
     
     %Need to account for no possible brancing detections 
     R_x_={}; R_y_=[];Test_id=[];
     
    if size(tDistances,1) == 0
        r_xCoord=x_of_full_fiber;r_yCoord=y_of_full_fiber;
        Id_coord=id_of_full_fiber;
        R_x_={r_xCoord};R_y_={r_yCoord};ID_coord_of_enclosed={Id_coord};
        ID_of_current_fiber=repmat(id_start, size(r_xCoord,1),1);
        ID_of_current_fiber1={ID_of_current_fiber};
        Test_id=[Test_id;ID_of_current_fiber1];
        All_possibilities=[R_x_,R_y_, Test_id, ID_coord_of_enclosed];
        
    elseif size(tDistances,1)~=0
         R_x_={r_xCoord};R_y_={r_yCoord};ID_coord_of_enclosed={Id_coord};
         ID_of_current_fiber=repmat(id_start, size(r_xCoord,1),1);
         ID_of_current_fiber1={ID_of_current_fiber};
         Test_id=[Test_id;ID_of_current_fiber1];
         All_possibilities=[R_x_, R_y_,Test_id, ID_coord_of_enclosed];
    end
 All_end_matrix=[All_end_matrix;All_possibilities]; 
 %This matrix has x, y, ID of fibre and IDs of proximal fibres 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

All_start_branch_matrix={};
for i=1:size(All_start_matrix,1)
    %Check through the matching IDs and extract parameters
    Current_id=cell2mat(All_start_matrix(i,3));
    Matching_ids=cell2mat(All_start_matrix(i,4));
    Subtraction=Matching_ids-Current_id;
    Matching_ids_seq=unique(Matching_ids);
    if sum(Subtraction)==0
        Branching={[]};
    elseif sum(Subtraction)~=0
     Matching_ids_seq(Matching_ids_seq==i)=[];
     Matching_ids_seq={Matching_ids_seq};
     Branching=Matching_ids_seq;
    end 
    All_start_branch_matrix=[All_start_branch_matrix;Branching]; 
end
%Get angles of branch     
All_angles_start={};
for j=1:size(All_start_branch_matrix,1);
    New_ordered_matching_sequences=All_start_branch_matrix{j,1};
    if size(New_ordered_matching_sequences,1)==0
       Angle_array={[]};    
    end

    if size(New_ordered_matching_sequences,1)~=0  
        Angle_array1=NaN(size(All_start_branch_matrix, 1),1)';
        Angle_array2=NaN(size(All_start_branch_matrix, 1),1)';
        Angle_array3=NaN(size(All_start_branch_matrix, 1),1)'; 
        F_interest_full=cell2mat(Mat_with_tracks_after_stitch(j,:));
        Begin_coord_current_id=Start_end_points_full(j,1:2);
        End_coord_current_id=Start_end_points_full(j,3:4);
        F_interest=[Begin_coord_current_id j; End_coord_current_id j];

            for o=1:size(New_ordered_matching_sequences,1)
                       mat_chopped=[];V_prec_2=[];V_prec_1=[];
                       V_prec_3=[];V_prec_4=[];V_prec_5=[];
                       V_prec_6=[];a=[]; b=[];a2=[];b2=[];a3=[];
                       b3=[];a4=[]; b4=[];a5=[];b5=[];a6=[];b6=[]; 
                       mat_tempo=[]; mat_tempo1=[];F_interest_chopped=[];     
                       mat_tempo1=cell2mat(Fibre_matrix(New_ordered_matching_sequences(o,1),1:3));
                       mat_tempo=unique(mat_tempo1, 'rows','stable');
                       dist_tempo=[];D=[];
                      
                                    for ii=1:size(mat_tempo,1)
                                            init=0;
                                            dist_tempo1=[];
                                            for jj=1:size(F_interest_full,1)
                                                dist_tempo1=sqrt((F_interest_full(jj,1)-mat_tempo(ii,1))^2+(F_interest_full(jj,2)-mat_tempo(ii,2))^2);
                                                D=[D;dist_tempo1];
                                                if init==0
                                                    min1=dist_tempo1;
                                                    init=1;   
                                                end
                                                if dist_tempo1<min1
                                                    min1=dist_tempo1;
                                                end
                                            end
                                            dist_tempo=[dist_tempo; min1];
                                     end

                            [~,idx]=min(dist_tempo);
                            Intersection=idx;Points_required=50;                                      
                            Size_mat=size(mat_tempo,1);
                            if Size_mat <=Points_required
                                mat_chopped=mat_tempo;
                            end
                                 if Size_mat>Points_required
                                            Distance_to_end=Size_mat-Intersection;
                                            Distance_to_start=Intersection-1;
                                            if Distance_to_end  >= (Points_required/2) && Distance_to_start >= (Points_required/2)
                                                mat_chopped=mat_tempo(Intersection-Points_required/2:Intersection+Points_required/2,:);
                                            end
                                            if Distance_to_end < Points_required/2 || Distance_to_start < Points_required/2 && Distance_to_start <Distance_to_end
                                                mat_chopped=mat_tempo(1:Points_required,:);
                                            end
                                             if Distance_to_end < Points_required/2 || Distance_to_start < Points_required/2 && Distance_to_start > Distance_to_end
                                                To_make_up=Points_required-Distance_to_end;
                                                mat_chopped=mat_tempo(Intersection-To_make_up:end,:);
                                             end
                                 end
                                mat_chopped1=[];mat_chopped2=[];
                                F_tempo=mat_tempo;
                                mat_tempo31=F_interest_full;
                                mat_tempo3=unique(mat_tempo31,'rows','stable');
                                dist_tempo3=[];D4=[];
                                
                                        for ii=1:size(mat_tempo3,1)
                                            init=0;
                                            dist_tempo2=[];
                                            for jj=1:size(F_tempo,1)
                                                dist_tempo2=sqrt((F_tempo(jj,1)-mat_tempo3(ii,1))^2+(F_tempo(jj,2)-mat_tempo3(ii,2))^2);
                                                D4=[D4;dist_tempo2];
                                                if init==0
                                                    min2=dist_tempo2;
                                                    init=1;   
                                                end
                                                if dist_tempo2<min2
                                                    min2=dist_tempo2;
                                                end
                                            end
                                            dist_tempo3=[dist_tempo3; min2];
                                        end                           

                                        [~,idx]=min(dist_tempo3);
                                        Intersection=idx;
                                        Points_required=50;
                                        Size_F=size(mat_tempo3,1);

                                        if Size_F <=Points_required
                                            F_interest_chopped=mat_tempo3;
                                        end
                                      if Size_F>Points_required
                                            Distance_to_end=Size_F-Intersection;
                                            Distance_to_start=Intersection-1;
                                            if Distance_to_end  >= (Points_required/2) && Distance_to_start >= (Points_required/2)
                                                F_interest_chopped=mat_tempo3(Intersection-Points_required/2:Intersection+Points_required/2,:);
                                            end

                                            if Distance_to_end < Points_required/2 || Distance_to_start < Points_required/2 && Distance_to_start <Distance_to_end
                                                F_interest_chopped=mat_tempo3(1:Points_required,:);
                                            end
                                             if Distance_to_end < Points_required/2 || Distance_to_start < Points_required/2 && Distance_to_start > Distance_to_end
                                                To_make_up=Points_required-Distance_to_end;
                                                F_interest_chopped=mat_tempo3(Intersection-To_make_up:end,:);
                                             end
                                        end
       
                                Mat_sorted=[]; Percentage1=20;Percentage2=50;Percentage3=100;
                                Mat_sorted=unique(F_interest_chopped(:,1:3), 'rows','stable');
                                if size(Mat_sorted, 1) <=7
                                     Behind=2;
                                     Fiber_start_x=Mat_sorted(1,1);
                                     Fiber_start_y=Mat_sorted(1,2);
                                     Fiber_end_x=Mat_sorted((end),1);
                                     Fiber_end_y=Mat_sorted((end),2);
                                     a=Fiber_end_x-Fiber_start_x;
                                     b=Fiber_end_y-Fiber_start_y;
                                     V_prec_1=[a b];
                                     V_ref=[1 0];
                                     signe=sign(a*b);
                                     scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                                     Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                                     Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                                     angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));
                                     V_prec_2=V_prec_1;
                                     V_prec_3=V_prec_1;
                                end

                                %%% Get the 3 percentage vectors     
                                if size(Mat_sorted,1)>7
                                    Number_of_points_per_fiber1=size(Mat_sorted,1);
                                    To_take=Number_of_points_per_fiber1*(Percentage1./100);
                                    Behind=ceil(To_take);
                                    Fiber_start_x=Mat_sorted(1,1);
                                    Fiber_start_y=Mat_sorted(1,2);
                                    Fiber_end_x=Mat_sorted((Behind),1);
                                    Fiber_end_y=Mat_sorted((Behind),2);
                                    a=Fiber_end_x-Fiber_start_x;
                                    b=Fiber_end_y-Fiber_start_y;
                                    V_prec_1=[a b];
                                    V_ref=[1 0];
                                    signe=sign(a*b);
                                    scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                                    Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                                    Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                                    angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));

                                    To_take2=Number_of_points_per_fiber1*(Percentage2./100);
                                    Behind2=ceil(To_take2);
                                    Fiber_start_x2=Mat_sorted(1,1);
                                    Fiber_start_y2=Mat_sorted(1,2);
                                    Fiber_end_x2=Mat_sorted((Behind2),1);
                                    Fiber_end_y2=Mat_sorted((Behind2),2);
                                    a2=Fiber_end_x2-Fiber_start_x2;
                                    b2=Fiber_end_y2-Fiber_start_y2;
                                    V_prec_2=[a2 b2];
                                    V_ref=[1 0];
                                    signe=sign(a2*b2);
                                    scalar_product2=V_prec_2(1)*V_ref(1)+V_prec_2(2)*V_ref(2);
                                    Norme_V_ref2=sqrt(V_ref(1)^2+V_ref(2)^2);
                                    Norme_V2=sqrt(V_prec_2(1)^2+V_prec_2(2)^2);
                                    angle_measured2=acos(scalar_product2/(Norme_V_ref2*Norme_V2));

                                    To_take3=Number_of_points_per_fiber1*(Percentage3./100);
                                    Behind3=ceil(To_take3);
                                    Fiber_start_x3=Mat_sorted(1,1);
                                    Fiber_start_y3=Mat_sorted(1,2);
                                    Fiber_end_x3=Mat_sorted((Behind3),1);
                                    Fiber_end_y3=Mat_sorted((Behind3),2);
                                    a3=Fiber_end_x3-Fiber_start_x3;
                                    b3=Fiber_end_y3-Fiber_start_y3;
                                    V_prec_3=[a3 b3];
                                    V_ref=[1 0];
                                    signe=sign(a3*b3);
                                    scalar_product3=V_prec_3(1)*V_ref(1)+V_prec_3(2)*V_ref(2);
                                    Norme_V_ref3=sqrt(V_ref(1)^2+V_ref(2)^2);
                                    Norme_V3=sqrt(V_prec_3(1)^2+V_prec_3(2)^2);
                                    angle_measured3=acos(scalar_product3/(Norme_V_ref3*Norme_V3));
                                end
                                
                                Mat_sorted_chopped=[];
                                Mat_sorted_chopped=unique(mat_chopped(:,1:3), 'rows','stable');
                                if size(Mat_sorted_chopped, 1) <=7
                                     Behind4=2;
                                     Fiber_start_x4=Mat_sorted_chopped(1,1);
                                     Fiber_start_y4=Mat_sorted_chopped(1,2);
                                     Fiber_end_x4=Mat_sorted_chopped((end),1);
                                     Fiber_end_y4=Mat_sorted_chopped((end),2);
                                     a4=Fiber_end_x4-Fiber_start_x4;
                                     b4=Fiber_end_y4-Fiber_start_y4;
                                     V_prec_4=[a4 b4];
                                     V_ref=[1 0];
                                     signe=sign(a*b);
                                     scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                                     Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                                     Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                                     angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));
                                     V_prec_5=V_prec_4;
                                     V_prec_6=V_prec_4;
                                end

                                if size(Mat_sorted_chopped,1)>7
                                    Number_of_points_per_fiber4=size(Mat_sorted_chopped,1);
                                    To_take4=Number_of_points_per_fiber4*(Percentage1./100);
                                    Behind4=ceil(To_take4);
                                    Fiber_start_x4=Mat_sorted_chopped(1,1);
                                    Fiber_start_y4=Mat_sorted_chopped(1,2);
                                    Fiber_end_x4=Mat_sorted_chopped((Behind4),1);
                                    Fiber_end_y4=Mat_sorted_chopped((Behind4),2);
                                    a4=Fiber_end_x4-Fiber_start_x4;
                                    b4=Fiber_end_y4-Fiber_start_y4;
                                    V_prec_4=[a4 b4];
                                    V_ref=[1 0];
                                    signe=sign(a4*b4);
                                    scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                                    Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                                    Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                                    angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));

                                    To_take5=Number_of_points_per_fiber4*(Percentage2./100);
                                    Behind5=ceil(To_take5);
                                    Fiber_start_x5=Mat_sorted_chopped(1,1);
                                    Fiber_start_y5=Mat_sorted_chopped(1,2);
                                    Fiber_end_x5=Mat_sorted_chopped((Behind5),1);
                                    Fiber_end_y5=Mat_sorted_chopped((Behind5),2);
                                    a5=Fiber_end_x5-Fiber_start_x5;
                                    b5=Fiber_end_y5-Fiber_start_y5;
                                    V_prec_5=[a5 b5];
                                    V_ref=[1 0];
                                    signe=sign(a5*b5);
                                    scalar_product5=V_prec_5(1)*V_ref(1)+V_prec_5(2)*V_ref(2);
                                    Norme_V_ref5=sqrt(V_ref(1)^2+V_ref(2)^2);
                                    Norme_V5=sqrt(V_prec_5(1)^2+V_prec_5(2)^2);
                                    angle_measured5=acos(scalar_product5/(Norme_V_ref5*Norme_V5));

                                    To_take6=Number_of_points_per_fiber4*(Percentage3./100);
                                    Behind6=ceil(To_take6);
                                    Fiber_start_x6=Mat_sorted_chopped(1,1);
                                    Fiber_start_y6=Mat_sorted_chopped(1,2);
                                    Fiber_end_x6=Mat_sorted_chopped((Behind6),1);
                                    Fiber_end_y6=Mat_sorted_chopped((Behind6),2);
                                    a6=Fiber_end_x6-Fiber_start_x6;
                                    b6=Fiber_end_y6-Fiber_start_y6;
                                    V_prec_6=[a6 b6];
                                    V_ref=[1 0];
                                    signe=sign(a6*b6);
                                    scalar_product6=V_prec_6(1)*V_ref(1)+V_prec_6(2)*V_ref(2);
                                    Norme_V_ref6=sqrt(V_ref(1)^2+V_ref(2)^2);
                                    Norme_V6=sqrt(V_prec_6(1)^2+V_prec_6(2)^2);
                                    angle_measured6=acos(scalar_product6/(Norme_V_ref6*Norme_V6));
                                end

                                if Behind && Behind4 <= 2
                                    V_prec_4=V_prec_1;
                                end

                                Matching_id=New_ordered_matching_sequences(o,1);
                                Vectors_new1_MAT=[V_prec_1 zeros(size(V_prec_1,1),1) signe angle_measured];
                                Vectors_new1_F=[V_prec_4 zeros(size(V_prec_4,1),1) signe angle_measured];
                                Vectors_new2_MAT=[V_prec_2 zeros(size(V_prec_1,1),1) signe angle_measured];
                                Vectors_new2_F=[V_prec_5 zeros(size(V_prec_4,1),1) signe angle_measured]; 
                                Vectors_new3_MAT=[V_prec_3 zeros(size(V_prec_1,1),1) signe angle_measured];
                                Vectors_new3_F=[V_prec_6 zeros(size(V_prec_4,1),1) signe angle_measured];
                                Angle_array1(1,Matching_id)=Angles_New_xref3(Vectors_new1_MAT, Vectors_new1_F);
                                Angle_array2(1,Matching_id)=Angles_New_xref3(Vectors_new2_MAT, Vectors_new2_F);
                                Angle_array3(1,Matching_id)=Angles_New_xref3(Vectors_new3_MAT, Vectors_new3_F);
            end
                Angle_array2(isnan(Angle_array2))=[];
                Angle_array2=Angle_array2';
                Angle_array={Angle_array2};
    end
   All_angles_start=[All_angles_start;Angle_array];     
end     

%Repeat for end matrix
All_end_branch_matrix={};
for i=1:size(All_end_matrix,1)  
    Current_id=cell2mat(All_end_matrix(i,3));
    Matching_ids=cell2mat(All_end_matrix(i,4));
    Subtraction=Matching_ids-Current_id;
    Matching_ids_seq=unique(Matching_ids);   
    if sum(Subtraction)==0
        Branching={[]};
    elseif sum(Subtraction)~=0   
     Matching_ids_seq(Matching_ids_seq==i)=[];
     Matching_ids_seq={Matching_ids_seq};
     Branching=Matching_ids_seq;
    end
    All_end_branch_matrix=[All_end_branch_matrix;Branching];
end
All_angles_end={};
    for j=1:size(All_end_branch_matrix,1);
        New_ordered_matching_sequences=All_end_branch_matrix{j,1};
        if size(New_ordered_matching_sequences,1)==0
           Angle_array_end1={[]};    
        end
        if size(New_ordered_matching_sequences,1)~=0
            Angle_array1=NaN(size(All_end_branch_matrix, 1),1)';
            Angle_array2=NaN(size(All_end_branch_matrix, 1),1)';
            Angle_array3=NaN(size(All_end_branch_matrix, 1),1)';
            F_interest_full=cell2mat(Mat_with_tracks_after_stitch(j,:));
            Begin_coord_current_id=Start_end_points_full(j,1:2);
            End_coord_current_id=Start_end_points_full(j,3:4);
            F_interest=[Begin_coord_current_id j; End_coord_current_id j];

        for o=1:size(New_ordered_matching_sequences,1)
                mat_chopped=[];V_prec_2=[];V_prec_1=[];V_prec_3=[];
                V_prec_4=[];V_prec_5=[];V_prec_6=[];a=[];b=[];a2=[];
                b2=[];a3=[];b3=[];a4=[];b4=[];a5=[];b5=[];a6=[];b6=[];               
                mat_tempo=[];mat_tempo1=[];F_interest_chopped=[];           

                mat_tempo1=cell2mat(Fibre_matrix(New_ordered_matching_sequences(o,1),1:3));
                mat_tempo=unique(mat_tempo1, 'rows','stable');
                dist_tempo=[];D=[];
                        for ii=1:size(F_interest,1)
                            init=0;
                            dist_tempo1=[];
                            for jj=1:size(mat_tempo,1)
                                dist_tempo1=sqrt((F_interest(ii,1)-mat_tempo(jj,1))^2+(F_interest(ii,2)-mat_tempo(jj,2))^2);
                                D=[D;dist_tempo1];
                                if init==0
                                    min1=dist_tempo1;
                                    init=1;   
                                end
                                if dist_tempo1<min1
                                    min1=dist_tempo1;
                                end
                            end
                            dist_tempo=[dist_tempo; min1];
                        end
                        
                         S=size(mat_tempo,1);
                         S2=size(D,1);
                         Start_point_split=D(1:S,:);
                         End_point_split=D(S+1:end,:);
                         [Row_begin, ~]=find(Start_point_split==dist_tempo(1,1));
                         Row_begin=Row_begin(1,1);
                         [Row_end,~]=find(End_point_split==dist_tempo(2,1));
                         Row_end=Row_end(1,1);
                         
                        if S<=10  
                            mat_chopped=mat_tempo;
                        end
                        if S>10
                                if Row_begin==Row_end
                                    Distance_from_end=S-Row_begin;
                                    Difference_to_make_upto10=10-Distance_from_end;
                                    if Distance_from_end>=10
                                         mat_chopped=mat_tempo(Row_begin:Row_begin+10,:);
                                    end  
                                    if Distance_from_end<10
                                              if Distance_from_end~=0
                                                    if Row_begin-Difference_to_make_upto10~=0
                                                         mat_chopped=mat_tempo(Row_begin-Difference_to_make_upto10:S,:);
                                                    end
                                                    if Row_begin-Difference_to_make_upto10==0
                                                      mat_chopped=mat_tempo(Row_begin-Difference_to_make_upto10+1:S,:);
                                                    end
                                              end
                                              if Distance_from_end==0
                                                 mat_chopped=mat_tempo(Row_begin-Difference_to_make_upto10+1:S,:); 
                                              end
                                    end                   
                                end 

                               if Row_begin~=Row_end 
                                   Difference_between_rows=abs(Row_begin-Row_end);
                                   if Difference_between_rows >= 10
                                            if Row_begin < Row_end
                                               mat_chopped=mat_tempo(Row_begin:Row_end,:);
                                            end
                                            if Row_begin >Row_end
                                               mat_chopped=mat_tempo(Row_end:Row_begin,:);
                                            end
                                   end
                                   if Difference_between_rows<10
                                       if Row_end < Row_begin
                                           Row_end1=Row_end;
                                           Row_end=Row_begin;
                                           Row_begin=Row_end1;
                                       end
                                   Difference_to_make_upto10=10-Difference_between_rows;
                                   Difference_behind=abs(1-Row_begin);
                                   Distance_to_end=S-Row_end;
                                   Difference_to_add=abs(Distance_to_end-Difference_to_make_upto10);
                                               if Distance_to_end >= 10
                                                   mat_chopped=mat_tempo(Row_begin:Row_begin+10,:);   
                                               end
                                               if Distance_to_end < 10 
                                                        if Difference_behind >=10
                                                            mat_chopped=mat_tempo(Row_end-10:Row_end,:);
                                                        end
                                                        if Difference_behind <10
                                                           mat_chopped=mat_tempo;
                                                        end
                                               end
                                   end
                           end    
                    end

                mat_chopped1=[];mat_chopped2=[];mat_chopped1=mat_chopped(1,:);
                mat_chopped2=mat_chopped(end,:);F_tempo=[mat_chopped1;mat_chopped2];
                mat_tempo31=F_interest_full;
                mat_tempo3=unique(mat_tempo31,'rows','stable');
                dist_tempo3=[];D4=[];
                            for ii=1:size(F_tempo,1)
                                init=0;
                                dist_tempo2=[];
                                for jj=1:size(mat_tempo3,1)
                                    dist_tempo2=sqrt((F_tempo(ii,1)-mat_tempo3(jj,1))^2+(F_tempo(ii,2)-mat_tempo3(jj,2))^2);
                                    D4=[D4;dist_tempo2];
                                    if init==0
                                        min2=dist_tempo2;
                                        init=1;   
                                    end
                                    if dist_tempo2<min2
                                        min2=dist_tempo2;
                                    end
                                end
                                dist_tempo3=[dist_tempo3; min2];
                            end                           
                            
                         S4=size(mat_tempo3,1);
                         Start_point_splitf=D4(1:S4,:);
                         End_point_splitf=D4(S4+1:end,:);
                        [Row_begin2, ~]=find(Start_point_splitf==dist_tempo3(1,1));
                        [Row_end2,~]=find(End_point_splitf==dist_tempo3(2,1));
                         Row_begin2=Row_begin2(1,1);
                         Row_end2=Row_end2(1,1);
                         S4=size(mat_tempo3,1);

                          if S4<=10  
                            F_interest_chopped=mat_tempo3;
                          end
                          
                        if S4>10
                                if Row_begin2==Row_end2
                                    Distance_from_end=S4-Row_begin2;
                                    Difference_to_make_upto10=10-Distance_from_end;
                                    if Distance_from_end>=10
                                         F_interest_chopped=mat_tempo3(Row_begin2:Row_begin2+10,:);
                                    end  
                                    if Distance_from_end<10
                                              if Distance_from_end~=0
                                                    if Row_begin2-Difference_to_make_upto10~=0
                                                         F_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10:S4,:);
                                                    end
                                                    if Row_begin2-Difference_to_make_upto10==0
                                                      F_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10+1:S4,:);
                                                    end
                                              end
                                              if Distance_from_end==0
                                                 F_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10+1:S4,:); 
                                              end
                                    end                   
                                end 

                               if Row_begin2~=Row_end2 
                                   Difference_between_rows=abs(Row_begin2-Row_end2);
                                   if Difference_between_rows >= 10
                                           if Row_begin2 < Row_end2
                                               F_interest_chopped=mat_tempo3(Row_begin2:Row_end2,:);
                                           end
                                           if Row_begin2 >Row_end2
                                               F_interest_chopped=mat_tempo3(Row_end2:Row_begin2,:);
                                           end
                                   end
                                   if Difference_between_rows<10
                                       if Row_end2 < Row_begin2
                                           Row_end1=Row_end2;
                                           Row_end2=Row_begin2;
                                           Row_begin2=Row_end1;
                                       end
                                   Difference_to_make_upto10=10-Difference_between_rows;
                                   Difference_behind=abs(1-Row_begin2);
                                   Distance_to_end=S4-Row_end2;
                                               if Distance_to_end >= 10
                                                   F_interest_chopped=mat_tempo3(Row_begin2:Row_begin2+10,:);   
                                               end
                                               if Distance_to_end < 10 
                                                        if Difference_behind >= 10
                                                            F_interest_chopped=mat_tempo3(Row_end2-10:Row_end2,:);
                                                        end
                                                        if Difference_behind < 10 
                                                            F_interest_chopped=mat_tempo3;
                                                        end
                                               end
                                   end
                           end    
                    end

                Mat_sorted=[];Mat_sorted_1=[];
                Mat_sorted_1=unique(F_interest_chopped, 'rows','stable');             
                M_1=floor(0.8*size(Mat_sorted_1,1));
                Difference_percentage=size(Mat_sorted_1,1)-M_1;
                D_over_2=floor(Difference_percentage./2);
                d_2=mod(Difference_percentage,2);
                Mat_sorted1=[];
                if d_2==1 %%number is odd
                    Mat_sorted1=Mat_sorted_1(D_over_2:end-1-D_over_2,:);
                end
                if d_2==0 %Number is even
                    Mat_sorted1=Mat_sorted_1(D_over_2:end-D_over_2,:);   
                end
                K2=[];K2=size(Mat_sorted1,1);
                if M_1 > 4
                    Mat_sorted=Mat_sorted1(K2-M_1:end, :);
                end
                if M_1 <=4
                     Mat_sorted=Mat_sorted1(1:end, :);
                end
                    Percentage1=20;
                    Percentage2=50;
                    Percentage3=75;
                            if size(Mat_sorted, 1) <=7
                                 Behind=2;
                                 Fiber_start_x=Mat_sorted(1,1);
                                 Fiber_start_y=Mat_sorted(1,2);
                                 Fiber_end_x=Mat_sorted((end),1);
                                 Fiber_end_y=Mat_sorted((end),2);
                                 a=Fiber_end_x-Fiber_start_x;
                                 b=Fiber_end_y-Fiber_start_y;
                                 V_prec_1=[a b];
                                 V_ref=[1 0];
                                 signe=sign(a*b);
                                 scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                                 Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                                 Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                                 angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));
                                 V_prec_2=V_prec_1;
                                 V_prec_3=V_prec_1;
                            end

                            %%% Get the 3 percentage vectors     
                            if size(Mat_sorted,1)>7
                                Number_of_points_per_fiber1=size(Mat_sorted,1);
                                To_take=Number_of_points_per_fiber1*(Percentage1./100);
                                Behind=ceil(To_take);
                                Fiber_start_x=Mat_sorted(1,1);
                                Fiber_start_y=Mat_sorted(1,2);
                                Fiber_end_x=Mat_sorted((Behind),1);
                                Fiber_end_y=Mat_sorted((Behind),2);
                                a=Fiber_end_x-Fiber_start_x;
                                b=Fiber_end_y-Fiber_start_y;
                                V_prec_1=[a b];
                                V_ref=[1 0];
                                signe=sign(a*b);
                                scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                                Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                                Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                                angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));


                                To_take2=Number_of_points_per_fiber1*(Percentage2./100);
                                Behind2=ceil(To_take2);
                                Fiber_start_x2=Mat_sorted(1,1);
                                Fiber_start_y2=Mat_sorted(1,2);
                                Fiber_end_x2=Mat_sorted((Behind2),1);
                                Fiber_end_y2=Mat_sorted((Behind2),2);
                                a2=Fiber_end_x2-Fiber_start_x2;
                                b2=Fiber_end_y2-Fiber_start_y2;
                                V_prec_2=[a2 b2];
                                V_ref=[1 0];
                                signe=sign(a2*b2);
                                scalar_product2=V_prec_2(1)*V_ref(1)+V_prec_2(2)*V_ref(2);
                                Norme_V_ref2=sqrt(V_ref(1)^2+V_ref(2)^2);
                                Norme_V2=sqrt(V_prec_2(1)^2+V_prec_2(2)^2);
                                angle_measured2=acos(scalar_product2/(Norme_V_ref2*Norme_V2));

                                To_take3=Number_of_points_per_fiber1*(Percentage3./100);
                                Behind3=ceil(To_take3);
                                Fiber_start_x3=Mat_sorted(1,1);
                                Fiber_start_y3=Mat_sorted(1,2);
                                Fiber_end_x3=Mat_sorted((Behind3),1);
                                Fiber_end_y3=Mat_sorted((Behind3),2);
                                a3=Fiber_end_x3-Fiber_start_x3;
                                b3=Fiber_end_y3-Fiber_start_y3;
                                V_prec_3=[a3 b3];
                                V_ref=[1 0];
                                signe=sign(a3*b3);
                                scalar_product3=V_prec_3(1)*V_ref(1)+V_prec_3(2)*V_ref(2);
                                Norme_V_ref3=sqrt(V_ref(1)^2+V_ref(2)^2);
                                Norme_V3=sqrt(V_prec_3(1)^2+V_prec_3(2)^2);
                                angle_measured3=acos(scalar_product3/(Norme_V_ref3*Norme_V3));
                            end
                            
                            Mat_sorted_chopped_1=[];
                            Mat_sorted_chopped_1=unique(mat_chopped, 'rows','stable');
                            M_2=floor(0.8*size(Mat_sorted_chopped_1,1));
                            Difference_percentage=size(Mat_sorted_chopped_1,1)-M_2;
                            D_over_2=floor(Difference_percentage./2);
                            d_2=mod(Difference_percentage,2);
                            Mat_sorted_chopped1=[];

                            if d_2==1 %%number is odd
                                Mat_sorted_chopped1=Mat_sorted_chopped_1(D_over_2:end-1-D_over_2,:);
                            end
                            if d_2==0 %Number is even
                                Mat_sorted_chopped1=Mat_sorted_chopped_1(D_over_2:end-D_over_2,:);   
                            end
                            K=[];
                            K=size(Mat_sorted_chopped1,1);
                             if M_2 > 4
                                Mat_sorted_chopped=Mat_sorted_chopped1(K-M_2:end, :);
                             end
                            if M_2 <=4
                                Mat_sorted_chopped=Mat_sorted_chopped1(1:end, :);
                            end

                            if size(Mat_sorted_chopped, 1) <=7
                                 Behind4=2;
                                 Fiber_start_x4=Mat_sorted_chopped(1,1);
                                 Fiber_start_y4=Mat_sorted_chopped(1,2);
                                 Fiber_end_x4=Mat_sorted_chopped((end),1);
                                 Fiber_end_y4=Mat_sorted_chopped((end),2);
                                 a4=Fiber_end_x4-Fiber_start_x4;
                                 b4=Fiber_end_y4-Fiber_start_y4;
                                 V_prec_4=[a4 b4];
                                 V_ref=[1 0];
                                 signe=sign(a*b);
                                 scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                                 Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                                 Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                                 angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));
                                 V_prec_5=V_prec_4;
                                 V_prec_6=V_prec_4;
                            end

                            if size(Mat_sorted_chopped,1)>7
                                Number_of_points_per_fiber4=size(Mat_sorted_chopped,1);
                                To_take4=Number_of_points_per_fiber4*(Percentage1./100);
                                Behind4=ceil(To_take4);
                                Fiber_start_x4=Mat_sorted_chopped(1,1);
                                Fiber_start_y4=Mat_sorted_chopped(1,2);
                                Fiber_end_x4=Mat_sorted_chopped((Behind4),1);
                                Fiber_end_y4=Mat_sorted_chopped((Behind4),2);
                                a4=Fiber_end_x4-Fiber_start_x4;
                                b4=Fiber_end_y4-Fiber_start_y4;
                                V_prec_4=[a4 b4];
                                V_ref=[1 0];
                                signe=sign(a4*b4);
                                scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                                Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                                Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                                angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));


                                To_take5=Number_of_points_per_fiber4*(Percentage2./100);
                                Behind5=ceil(To_take5);
                                Fiber_start_x5=Mat_sorted_chopped(1,1);
                                Fiber_start_y5=Mat_sorted_chopped(1,2);
                                Fiber_end_x5=Mat_sorted_chopped((Behind5),1);
                                Fiber_end_y5=Mat_sorted_chopped((Behind5),2);
                                a5=Fiber_end_x5-Fiber_start_x5;
                                b5=Fiber_end_y5-Fiber_start_y5;
                                V_prec_5=[a5 b5];
                                V_ref=[1 0];
                                signe=sign(a5*b5);
                                scalar_product5=V_prec_5(1)*V_ref(1)+V_prec_5(2)*V_ref(2);
                                Norme_V_ref5=sqrt(V_ref(1)^2+V_ref(2)^2);
                                Norme_V5=sqrt(V_prec_5(1)^2+V_prec_5(2)^2);
                                angle_measured5=acos(scalar_product5/(Norme_V_ref5*Norme_V5));

                                To_take6=Number_of_points_per_fiber4*(Percentage3./100);
                                Behind6=ceil(To_take6);
                                Fiber_start_x6=Mat_sorted_chopped(1,1);
                                Fiber_start_y6=Mat_sorted_chopped(1,2);
                                Fiber_end_x6=Mat_sorted_chopped((Behind6),1);
                                Fiber_end_y6=Mat_sorted_chopped((Behind6),2);
                                a6=Fiber_end_x6-Fiber_start_x6;
                                b6=Fiber_end_y6-Fiber_start_y6;
                                V_prec_6=[a6 b6];
                                V_ref=[1 0];
                                signe=sign(a6*b6);
                                scalar_product6=V_prec_6(1)*V_ref(1)+V_prec_6(2)*V_ref(2);
                                Norme_V_ref6=sqrt(V_ref(1)^2+V_ref(2)^2);
                                Norme_V6=sqrt(V_prec_6(1)^2+V_prec_6(2)^2);
                                angle_measured6=acos(scalar_product6/(Norme_V_ref6*Norme_V6));
                            end

                            if Behind && Behind4 <= 2
                                V_prec_4=V_prec_1;
                            end

                            Matching_id=New_ordered_matching_sequences(o,1);
                            Vectors_new1_MAT=[V_prec_1 zeros(size(V_prec_1,1),1) signe angle_measured];
                            Vectors_new1_F=[V_prec_4 zeros(size(V_prec_4,1),1) signe angle_measured];
                            Vectors_new2_MAT=[V_prec_2 zeros(size(V_prec_1,1),1) signe angle_measured];
                            Vectors_new2_F=[V_prec_5 zeros(size(V_prec_4,1),1) signe angle_measured]; 
                            Vectors_new3_MAT=[V_prec_3 zeros(size(V_prec_1,1),1) signe angle_measured];
                            Vectors_new3_F=[V_prec_6 zeros(size(V_prec_4,1),1) signe angle_measured];
                            Angle_array1(1,Matching_id)=Angles_New_xref3(Vectors_new1_MAT, Vectors_new1_F);
                            Angle_array2(1,Matching_id)=Angles_New_xref3(Vectors_new2_MAT, Vectors_new2_F);
                            Angle_array3(1,Matching_id)=Angles_New_xref3(Vectors_new3_MAT, Vectors_new3_F);
        end
        Angle_array2(isnan(Angle_array2))=[];
        Angle_array2=Angle_array2';
        Angle_array_end1={Angle_array2};
    end
All_angles_end=[All_angles_end;Angle_array_end1]; 
end  

%Get coords
Start_coords=[];
for i=1:size(All_start_branch_matrix,1)
    Read_in=All_start_branch_matrix{i,1};
    if size(Read_in,1)~=0     
        Start_coord=Start_end_points_full(i,1:2);
    else
        Start_coord=[];       
    end
    Start_coords=[Start_coords;Start_coord];
end

End_coords=[];
for i=1:size(All_end_branch_matrix,1) 
    Read_in=All_end_branch_matrix{i,1};   
    if size(Read_in,1)~=0      
        E_coord=Start_end_points_full(i,3:4);       
    else
        E_coord=[];    
    end  
   End_coords=[End_coords;E_coord]; 
end
%Combine all angles
All_branching_angles=[All_angles_start;All_angles_end];
Copy_all=All_branching_angles;
Copy_all(any(cellfun(@isempty,Copy_all),2),:) = [];
Branching_angles=cell2mat(Copy_all);

%Exclude those at the ROI boundaries 
Temp_coord_cell={};Filtered_coords=[];
Branched_coords1=[Start_coords;End_coords];
B=num2cell(Branched_coords1);
Temp_coord_cell=[Copy_all, B];%Angles (could be more than one as multiple fibres could branch from one) corresponding to the coords
Filtered_coords=Temp_coord_cell;
Copy=Filtered_coords;

Region=importdata('Region.txt');
ROI_Edges=[min(Region(:,1)), max(Region(:,1)), ...
    min(Region(:,2)), max(Region(:,2))];

if size(Filtered_coords,1)~=0
    for i=1:size(Filtered_coords,1)
        x_in=Filtered_coords{i,2};
        y_in=Filtered_coords{i,3};
        
            if x_in <= ROI_Edges(1)+Ripley_radius+r_of_search || x_in >= ROI_Edges(2)-Ripley_radius-r_of_search || y_in <=ROI_Edges(3)+Ripley_radius+r_of_search || y_in >= ROI_Edges(4)-Ripley_radius-r_of_search
                Index_delete=i;
                Filtered_coords(i,:)={[]};
            end
    end
    Filtered_coords(any(cellfun(@isempty,Filtered_coords),2),:)=[];
    Filtered_branch_angles=Filtered_coords(:,1);
    Filtered_branch_coords=Filtered_coords(:,2:3);
    Number_of_branching_points=size(Filtered_coords,1);
else
    Branched_coords=[];
    Filtered_branch_angles=[];
    Filtered_branch_coords=[];
    Number_of_branching_points=[];
    
end
end