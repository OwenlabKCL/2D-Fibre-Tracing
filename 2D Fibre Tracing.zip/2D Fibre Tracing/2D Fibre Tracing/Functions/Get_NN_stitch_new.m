%Input: x,y,id, localisation, tracks
%Output:X,y, id localisation tracks

function [Fiber_output_post_stitch,New_indicies_of_fibers_to_never_be_stitched]=Get_NN_stitch_new(Sorted_fibers_out2, Threshold_Angle,Threshold_NN,New_indicies_of_possible_unique_fibers)

Mat_all_averaged1=Sorted_fibers_out2;
Mat_all_averaged=[Mat_all_averaged1(:,1:4)]; 
[Fiber_input1]=Get_new_tracks(Mat_all_averaged);
Fiber_input=[Fiber_input1(:,1:3),Fiber_input1(:,5),Fiber_input1(:,4)];
num_sampliing_points=10;M=[];

for i=1:size(Fiber_input,1)  

    T=[];xy_per_ID=[];xy_per_joining=[];
    x_values=Fiber_input{i,1};
    y_values=Fiber_input{i,2};
    old_IDS=Fiber_input{i,3};
    origional_tracks=Fiber_input{i,4};
    Localisations=Fiber_input{i,5};
    U=unique(origional_tracks);
    
        for ii=1:size(x_values,1)-1
            xy_per_joining=[linspace(x_values(ii),x_values(ii+1),num_sampliing_points).'...
            linspace(y_values(ii),y_values(ii+1),num_sampliing_points).']; 
            xy_per_ID=[xy_per_ID; xy_per_joining];
        end  
        
    Newly_assigned_IDS=[xy_per_ID,repmat(i,length(xy_per_ID), 1)];
    T=repmat(U,length(xy_per_ID),1); %Based on sampling points per ID.... 
    M=[M;Newly_assigned_IDS T];
end

Sampling_points=M;
M_x= accumarray(M(:,3),M(:,1),[],@(v){v});
M_x(any(cellfun(@isempty,M_x),2),:) = [];
M_y= accumarray(M(:,3),M(:,2),[],@(v){v});
M_y(any(cellfun(@isempty,M_y),2),:) = [];
M_ID_artificial=accumarray(M(:,3),M(:,3),[],@(v){v});
M_ID_artificial(any(cellfun(@isempty,M_ID_artificial),2),:) = [];
M_tracks=accumarray(M(:,3),M(:,4),[],@(v){v});
M_tracks(any(cellfun(@isempty,M_tracks),2),:) = [];

%Assign IDS
for m=1:size(M_tracks, 1)
    IDS(m,1)={[repmat(m,size(Fiber_input{m,1},1),1)]};
end
Mat_with_new_IDS=[];
Mat_with_new_IDS=[Fiber_input(:,1:2) IDS Fiber_input(:,4) Fiber_input(:,5)];%x,y,ID, track,localisation
x_y_id_values_=[];Start_end_points_full=[];Matrix_to_accume=[];


%Sort matrix 
for i=1:size(Mat_with_new_IDS,1) 

   Matrix_x=[]; Matrix_y=[];Matrix_id=[];Matrix_to_sort=[]; To_order=[];
   x_y_id=Mat_with_new_IDS(i,:);
   
   for j=1:size(x_y_id, 1)
                       
         Matrix_x=x_y_id{j,1};
         Matrix_y=x_y_id{j,2};
         Matrix_id=x_y_id{j,3};
         Tracks=x_y_id{j,4};
         Localisations=x_y_id{j,5};
         Matrix_to_sort=[Matrix_x,Matrix_y,Matrix_id,Localisations,Tracks];
         
         %Check ordering 
          To_order=Matrix_to_sort;
          [~, orientation] = max([std(To_order(:,1)),std(To_order(:,2))]);
              if orientation==1
                   Matrix_sorted=sortrows(To_order, 1);
              elseif orientation==2 
                   Matrix_sorted=sortrows(To_order, 2);
              end
                       
          Matrix_sorted1=unique(Matrix_sorted, 'rows','stable');
          Fiber_start_x_full=Matrix_sorted1(1,1);
          Fiber_start_y_full=Matrix_sorted1(1,2);
          Fiber_end_x_full=Matrix_sorted1(end,1);
          Fiber_end_y_full=Matrix_sorted1(end, 2);
         Matrix_to_accume=[Matrix_to_accume;Matrix_sorted];   
   end
 Start_end_points_full=[Start_end_points_full;Fiber_start_x_full ,...
     Fiber_start_y_full, Fiber_end_x_full,Fiber_end_y_full];          
end

x_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,1),[],@(v){v});
x_1(any(cellfun(@isempty,x_1),2),:) = [];
y_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,2),[],@(v){v});
y_1(any(cellfun(@isempty,y_1),2),:) = [];
id_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,3),[],@(v){v});
id_1(any(cellfun(@isempty,id_1),2),:) = [];
Loc_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,4),[],@(v){v});
Loc_1(any(cellfun(@isempty,Loc_1),2),:) = [];
Track_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,5),[],@(v){v});
Track_1(any(cellfun(@isempty,Track_1),2),:) = [];
Mat_with_tracks_after_stitch_sorted=[x_1, y_1, id_1,Loc_1,Track_1];

Mat=[];
for e=1:size(Mat_with_tracks_after_stitch_sorted,1)
    Vector_IDS=unique(cell2mat(Mat_with_tracks_after_stitch_sorted(e,3)));
    Mat=[Mat; Vector_IDS];
end
Start_end_points_full(:,5)=Mat;
S1=size(Mat_with_tracks_after_stitch_sorted, 1);
All_fibers = 1:S1;
M=zeros(size(Mat_with_tracks_after_stitch_sorted,1),1);
M=num2cell(M);
All_fibers2=All_fibers';

for i=1:size(M,1)
    M(i,1)={All_fibers2};
end

All=[Mat_with_tracks_after_stitch_sorted(:,1:3),M];%x,y,id, enclosing

%Do NN array for distance calculations
NN_array=zeros(size(Mat_with_tracks_after_stitch_sorted,1),...
    size(Mat_with_tracks_after_stitch_sorted,1));
for j=1:size(Mat_with_tracks_after_stitch_sorted,1)  
        M_interest=[];
        for b=1:size(Sampling_points,1)
                if Sampling_points(b,3)==j
                   M_interest=[M_interest; Sampling_points(b,1:2)] ;
                end
        end      
    for h=1:size(Mat_with_tracks_after_stitch_sorted,1) 
            mat_tempo=[];     
        for b=1:size(Sampling_points,1)
               if Sampling_points(b,3)==h
                   mat_tempo=[mat_tempo;Sampling_points(b,1:2)] ;
                end
        end
    NN_array(j,h)=Get_NND(M_interest, mat_tempo); 
    NN_array_T=NN_array';
    end  
end

%Do NN array for angles
NN_angles_1=[];NN_angles_2=[];NN_angles_3=[];
for t=1:size(All, 1)
    Fibre_interest=[]; 
    Matching_ids=cell2mat(All(t,4));
    Matching_ids_sequence=unique(Matching_ids);
    Matching_ids_sequence(Matching_ids_sequence==t)=[];
    
     if size(Matching_ids_sequence,2) ~= 0   
           Fiber_end_x=[];Fiber_start_x=[]; Fiber_start_y=[];Fiber_end_y=[];     
           Tracks=Mat_with_tracks_after_stitch_sorted(Matching_ids_sequence,5);
           Id_of_biggest=Mat_with_tracks_after_stitch_sorted(Matching_ids_sequence,3);
           Both=[Id_of_biggest, Tracks];C=cell2mat(Both);
           [R,col]=max(C(:,2));ID=C(col, 1);X=sortrows(C,-2);
           New_ordered_matching_sequences=unique(X(:,1), 'stable');
           
           Begin_coord_current_id=Start_end_points_full(t,1:2);
           End_coord_current_id=Start_end_points_full(t,3:4);           
           NN_array1=NaN(size(Start_end_points_full,1),1)';
           NN_array2=NaN(size(Start_end_points_full,1),1)';
           NN_array3=NaN(size(Start_end_points_full,1),1)';
                        
           Fibre_interest=[Begin_coord_current_id t; End_coord_current_id t];
           Fibre_interest_full=cell2mat(Mat_with_tracks_after_stitch_sorted(t, :));
              
                    for o=1:size(New_ordered_matching_sequences,1)
                           mat_chopped=[];V_prec_2=[];V_prec_1=[];V_prec_3=[];
                           V_prec_4=[];V_prec_5=[];V_prec_6=[];a=[];b=[];
                           a2=[];b2=[];a3=[]; b3=[];a4=[]; b4=[]; a5=[];
                           b5=[]; a6=[];b6=[];mat_tempo=[];mat_tempo1=[];
                           Fibre_interest_chopped=[];
                           mat_tempo1=cell2mat(Mat_with_tracks_after_stitch_sorted(New_ordered_matching_sequences(o,1),1:3));
                           mat_tempo=unique(mat_tempo1, 'rows','stable');
                           %Check ordering 
                           To_order=[];
                           To_order=mat_tempo;
                          [~, orientation] = max([std(To_order(:,1)),std(To_order(:,2))]);

                          if orientation==1
                               mat_tempo=sortrows(To_order, 1);
                          elseif orientation==2
                               mat_tempo=sortrows(To_order, 2);
                          end
                        
                        %Get NN distance matrix between fibre anf fibre of interest for all  
                        dist_tempo=[];
                        D=[];
                                for ii=1:size(Fibre_interest,1)
                                    init=0;
                                    dist_tempo1=[];
                                    for jj=1:size(mat_tempo,1)
                                        dist_tempo1=sqrt((Fibre_interest(ii,1)-mat_tempo(jj,1))^2+(Fibre_interest(ii,2)-mat_tempo(jj,2))^2);
                                        D=[D;dist_tempo1];
                                        if init==0
                                            min1=dist_tempo1;
                                            init=1;    
                                        end
                                        if dist_tempo1<min1
                                            min1=dist_tempo1;                                         
                                        end       
                                    end
                                    dist_tempo=[dist_tempo; min1];
                                end
                                
                    S=size(mat_tempo,1); S2=size(D,1);
                    Start_point_split=D(1:S,:); End_point_split=D(S+1:end,:);  
                    [Row_begin, ~]=find(Start_point_split==dist_tempo(1,1));
                    [Row_end,~]=find(End_point_split==dist_tempo(2,1));
                    Row_begin=Row_begin(1,1);Row_end=Row_end(1,1);
  
                    if S<=10  
                        mat_chopped=mat_tempo;
                    end
   
                    if S>10
                           if Row_begin==Row_end
                                Distance_from_end=S-Row_begin;
                                Difference_to_make_upto10=10-Distance_from_end;
                                if Distance_from_end>=10
                                     mat_chopped=mat_tempo(Row_begin:Row_begin+10,:);
                                end            
                                if Distance_from_end<10 
                                          if Distance_from_end~=0
                                                if Row_begin-Difference_to_make_upto10~=0
                                                     mat_chopped=mat_tempo(Row_begin-Difference_to_make_upto10:S,:);
                                                end
                                                if Row_begin-Difference_to_make_upto10==0
                                                  mat_chopped=mat_tempo(Row_begin-Difference_to_make_upto10+1:S,:);
                                                end
                                          end     
                                          if Distance_from_end==0
                                             mat_chopped=mat_tempo(Row_begin-Difference_to_make_upto10+1:S,:); 
                                          end
                                end                      
                           end 
                            
                           if Row_begin~=Row_end       
                               Difference_between_rows=abs(Row_begin-Row_end);
                               if Difference_between_rows >= 10
                                        if Row_begin < Row_end
                                               mat_chopped=mat_tempo(Row_begin:Row_end,:);
                                        end
                                        if Row_begin >Row_end
                                               mat_chopped=mat_tempo(Row_end:Row_begin,:);
                                        end                               
                               end
                               if Difference_between_rows<10       
                                   if Row_end < Row_begin
                                       Row_end1=Row_end;
                                       Row_end=Row_begin;
                                       Row_begin=Row_end1;
                                       
                                   end
                               Difference_to_make_upto10=10-Difference_between_rows;
                               Difference_behind=abs(1-Row_begin);
                               Distance_to_end=S-Row_end;
                               Difference_to_add=abs(Distance_to_end-Difference_to_make_upto10);
                                   
                                           if Distance_to_end >= 10
                                               mat_chopped=mat_tempo(Row_begin:Row_begin+10,:);   
                                           end
                                           if Distance_to_end < 10 
                                                    if Difference_behind >=10
                                                        mat_chopped=mat_tempo(Row_end-10:Row_end,:);
                                                    end
                                                    if Difference_behind <10                                                
                                                       mat_chopped=mat_tempo;
                                                    end
                                           end
                               end
                       end    
                    end                 
                       
                        %Repeat for fibres of interest
                        mat_chopped1=[];mat_chopped2=[];
                        mat_chopped1=mat_chopped(1,:);
                        mat_chopped2=mat_chopped(end,:);
                        F_tempo=[mat_chopped1;mat_chopped2];
                        
                        mat_tempo31=Fibre_interest_full(:,1:3) ;
                        mat_tempo3=unique(mat_tempo31,'rows','stable');
                         %Check still in right order
                         To_order=[];
                         To_order=mat_tempo3;
                         [~, orientation] = max([std(To_order(:,1)),std(To_order(:,2))]);
                          if orientation==1
                               mat_tempo3=sortrows(To_order, 1);
                          elseif orientation==2
                               mat_tempo3=sortrows(To_order, 2);
                          end
                        
                        dist_tempo3=[];
                        D4=[];
                                for ii=1:size(F_tempo,1)
                                    init=0;
                                    dist_tempo2=[];
                                    for jj=1:size(mat_tempo3,1)
                                        dist_tempo2=sqrt((F_tempo(ii,1)-mat_tempo3(jj,1))^2+(F_tempo(ii,2)-mat_tempo3(jj,2))^2);
                                        D4=[D4;dist_tempo2];
                                        if init==0
                                            min2=dist_tempo2;
                                            init=1;                            
                                        end                                        
                                        if dist_tempo2<min2
                                            min2=dist_tempo2;
                                        end    
                                    end
                                    dist_tempo3=[dist_tempo3; min2];
                                end                           
                                
                     S4=size(mat_tempo3,1);
                     Start_point_splitf=D4(1:S4,:);
                     End_point_split_mat=D4(S4+1:end,:);

                     [Row_begin2, ~]=find(Start_point_splitf==dist_tempo3(1,1));
                     [Row_end2,~]=find(End_point_split_mat==dist_tempo3(2,1));
                     Row_begin2=Row_begin2(1,1);
                     Row_end2=Row_end2(1,1);
                     S4=size(mat_tempo3,1);

                      if S4<=10  
                        Fibre_interest_chopped=mat_tempo3;
                      end   
                      
                    if S4>10
                            if Row_begin2==Row_end2
                                Distance_from_end=S4-Row_begin2;
                                Difference_to_make_upto10=10-Distance_from_end;
                                if Distance_from_end>=10        
                                     Fibre_interest_chopped=mat_tempo3(Row_begin2:Row_begin2+10,:);
                                end  
                                if Distance_from_end<10
                                          if Distance_from_end~=0
                                                if Row_begin2-Difference_to_make_upto10~=0           
                                                     Fibre_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10:S4,:);
                                                end
                                                
                                                if Row_begin2-Difference_to_make_upto10==0
                                                  Fibre_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10+1:S4,:);
                                                end       
                                          end
                                          if Distance_from_end==0
                                             Fibre_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10+1:S4,:); 
                                          end   
                                end                          
                            end    
                           
                           if Row_begin2~=Row_end2    
                               Difference_between_rows=abs(Row_begin2-Row_end2);
                               if Difference_between_rows >= 10
                                        if Row_begin2 < Row_end2
                                               Fibre_interest_chopped=mat_tempo3(Row_begin2:Row_end2,:);
                                        end
                                        if Row_begin2 >Row_end2
                                               Fibre_interest_chopped=mat_tempo3(Row_end2:Row_begin2,:);
                                        end 
                               end            
                               if Difference_between_rows<10        
                                   if Row_end2 < Row_begin2
                                       Row_end1=Row_end2;
                                       Row_end2=Row_begin2;
                                       Row_begin2=Row_end1;
                                       
                                   end 
                               Difference_to_make_upto10=10-Difference_between_rows;
                               Difference_behind=abs(1-Row_begin2);
                               Distance_to_end=S4-Row_end2; 
                                           if Distance_to_end >= 10
                                               Fibre_interest_chopped=mat_tempo3(Row_begin2:Row_begin2+10,:);   
                                           end
                                           if Distance_to_end < 10                                              
                                                    if Difference_behind >= 10 
                                                        Fibre_interest_chopped=mat_tempo3(Row_end2-10:Row_end2,:);
                                                    end                                               
                                                    if Difference_behind < 10 
                                                        Fibre_interest_chopped=mat_tempo3;%(Row_begin2-Difference_behind:Row_begin2+X,:);
                                                    end
                                           end
                               end     
                       end    
                    end
                    
                       %Has to be done for each iteration of new sequences.....    
                       %Get angle of F_interest ....  
                        Mat_sorted=[];Mat_sorted_1=[];   
                        Mat_sorted_1=unique(Fibre_interest_chopped, 'rows','stable');               
                        M_1=ceil(0.8*size(Mat_sorted_1,1));
                        Difference_percentage=size(Mat_sorted_1,1)-M_1;
                        D_over_2=floor(Difference_percentage./2);
                        d_2=mod(Difference_percentage,2);
                        Mat_sorted1=[];
                        
                        if d_2==1 && D_over_2~=0%%number is odd
                            Mat_sorted1=Mat_sorted_1(D_over_2:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2~=0 %Number is even
                            Mat_sorted1=Mat_sorted_1(D_over_2:end-D_over_2,:);   
                        end
                         if d_2==1 && D_over_2==0%%number is odd
                            Mat_sorted1=Mat_sorted_1(1:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2==0 %Number is even
                            Mat_sorted1=Mat_sorted_1(1:end-D_over_2,:);   
                        end          
                        Mat_sorted=Mat_sorted1;
                        Percentage1=20;
                        Percentage2=50;
                        Percentage3=75;
                        
                        if size(Mat_sorted, 1) <=7
                             Behind=2;
                             Fiber_start_x=Mat_sorted(1,1);
                             Fiber_start_y=Mat_sorted(1,2);
                             Fiber_end_x=Mat_sorted((end),1);
                             Fiber_end_y=Mat_sorted((end),2);
                             a=Fiber_end_x-Fiber_start_x;
                             b=Fiber_end_y-Fiber_start_y;
                             V_prec_1=[a b];
                             V_ref=[1 0];
                             signe=sign(a*b);
                             scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                             Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                             Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                             angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));
                             V_prec_2=V_prec_1;
                             V_prec_3=V_prec_1;
                             
                        end
                        
                        %%% Get the 3 percentage vectors     
                        if size(Mat_sorted,1)>7   
                            Number_of_points_per_fiber1=size(Mat_sorted,1);
                            To_take=Number_of_points_per_fiber1*(Percentage1./100);
                            Behind=ceil(To_take);
                            Fiber_start_x=Mat_sorted(1,1);
                            Fiber_start_y=Mat_sorted(1,2);
                            Fiber_end_x=Mat_sorted((Behind),1);
                            Fiber_end_y=Mat_sorted((Behind),2);
                            a=Fiber_end_x-Fiber_start_x;
                            b=Fiber_end_y-Fiber_start_y;
                            V_prec_1=[a b];
                            V_ref=[1 0];
                            signe=sign(a*b);
                            scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                            Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                            angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));


                            To_take2=Number_of_points_per_fiber1*(Percentage2./100);
                            Behind2=ceil(To_take2);
                            Fiber_start_x2=Mat_sorted(1,1);
                            Fiber_start_y2=Mat_sorted(1,2);
                            Fiber_end_x2=Mat_sorted((Behind2),1);
                            Fiber_end_y2=Mat_sorted((Behind2),2);
                            a2=Fiber_end_x2-Fiber_start_x2;
                            b2=Fiber_end_y2-Fiber_start_y2;
                            V_prec_2=[a2 b2];
                            V_ref=[1 0];
                            signe=sign(a2*b2);
                            scalar_product2=V_prec_2(1)*V_ref(1)+V_prec_2(2)*V_ref(2);
                            Norme_V_ref2=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V2=sqrt(V_prec_2(1)^2+V_prec_2(2)^2);
                            angle_measured2=acos(scalar_product2/(Norme_V_ref2*Norme_V2));

                            To_take3=Number_of_points_per_fiber1*(Percentage3./100);
                            Behind3=ceil(To_take3);
                            Fiber_start_x3=Mat_sorted(1,1);
                            Fiber_start_y3=Mat_sorted(1,2);
                            Fiber_end_x3=Mat_sorted((Behind3),1);
                            Fiber_end_y3=Mat_sorted((Behind3),2);
                            a3=Fiber_end_x3-Fiber_start_x3;
                            b3=Fiber_end_y3-Fiber_start_y3;
                            V_prec_3=[a3 b3];
                            V_ref=[1 0];
                            signe=sign(a3*b3);
                            scalar_product3=V_prec_3(1)*V_ref(1)+V_prec_3(2)*V_ref(2);
                            Norme_V_ref3=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V3=sqrt(V_prec_3(1)^2+V_prec_3(2)^2);
                            angle_measured3=acos(scalar_product3/(Norme_V_ref3*Norme_V3));
                        end
                        %Repeat
                        Mat_sorted_chopped_1=[];
                        Mat_sorted_chopped_1=unique(mat_chopped, 'rows','stable');
                        M_2=ceil(0.8*size(Mat_sorted_chopped_1,1));
                        Difference_percentage=size(Mat_sorted_chopped_1,1)-M_2;
                        D_over_2=floor(Difference_percentage./2);
                        d_2=mod(Difference_percentage,2);
                        Mat_sorted_chopped1=[];
                        
                        if d_2==1 && D_over_2~=0%%number is odd
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(D_over_2:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2~=0%Number is even
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(D_over_2:end-D_over_2,:);   
                        end
                             
                        if d_2==1 && D_over_2==0%%number is odd
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(1:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2==0%Number is even
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(1:end-D_over_2,:);   
                        end
                        Mat_sorted_chopped=Mat_sorted_chopped1;
                     
                        if size(Mat_sorted_chopped, 1) <=7
                             Behind4=2;
                             Fiber_start_x4=Mat_sorted_chopped(1,1);
                             Fiber_start_y4=Mat_sorted_chopped(1,2);
                             Fiber_end_x4=Mat_sorted_chopped((end),1);
                             Fiber_end_y4=Mat_sorted_chopped((end),2);
                             a4=Fiber_end_x4-Fiber_start_x4;
                             b4=Fiber_end_y4-Fiber_start_y4;
                             V_prec_4=[a4 b4];
                             V_ref=[1 0];
                             signe=sign(a*b);
                             scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                             Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                             Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                             angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));
                             V_prec_5=V_prec_4;
                             V_prec_6=V_prec_4;
                             
                        end
                        
                        if size(Mat_sorted_chopped,1)>7 
                            Number_of_points_per_fiber4=size(Mat_sorted_chopped,1);
                            To_take4=Number_of_points_per_fiber4*(Percentage1./100);
                            Behind4=ceil(To_take4);
                            Fiber_start_x4=Mat_sorted_chopped(1,1);
                            Fiber_start_y4=Mat_sorted_chopped(1,2);
                            Fiber_end_x4=Mat_sorted_chopped((Behind4),1);
                            Fiber_end_y4=Mat_sorted_chopped((Behind4),2);
                            a4=Fiber_end_x4-Fiber_start_x4;
                            b4=Fiber_end_y4-Fiber_start_y4;
                            V_prec_4=[a4 b4];
                            V_ref=[1 0];
                            signe=sign(a4*b4);
                            scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                            Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                            angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));


                            To_take5=Number_of_points_per_fiber4*(Percentage2./100);
                            Behind5=ceil(To_take5);
                            Fiber_start_x5=Mat_sorted_chopped(1,1);
                            Fiber_start_y5=Mat_sorted_chopped(1,2);
                            Fiber_end_x5=Mat_sorted_chopped((Behind5),1);
                            Fiber_end_y5=Mat_sorted_chopped((Behind5),2);
                            a5=Fiber_end_x5-Fiber_start_x5;
                            b5=Fiber_end_y5-Fiber_start_y5;
                            V_prec_5=[a5 b5];
                            V_ref=[1 0];
                            signe=sign(a5*b5);
                            scalar_product5=V_prec_5(1)*V_ref(1)+V_prec_5(2)*V_ref(2);
                            Norme_V_ref5=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V5=sqrt(V_prec_5(1)^2+V_prec_5(2)^2);
                            angle_measured5=acos(scalar_product5/(Norme_V_ref5*Norme_V5));

                            To_take6=Number_of_points_per_fiber4*(Percentage3./100);
                            Behind6=ceil(To_take6);
                            Fiber_start_x6=Mat_sorted_chopped(1,1);
                            Fiber_start_y6=Mat_sorted_chopped(1,2);
                            Fiber_end_x6=Mat_sorted_chopped((Behind6),1);
                            Fiber_end_y6=Mat_sorted_chopped((Behind6),2);
                            a6=Fiber_end_x6-Fiber_start_x6;
                            b6=Fiber_end_y6-Fiber_start_y6;
                            V_prec_6=[a6 b6];
                            V_ref=[1 0];
                            signe=sign(a6*b6);
                            scalar_product6=V_prec_6(1)*V_ref(1)+V_prec_6(2)*V_ref(2);
                            Norme_V_ref6=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V6=sqrt(V_prec_6(1)^2+V_prec_6(2)^2);
                            angle_measured6=acos(scalar_product6/(Norme_V_ref6*Norme_V6));    
                        end
                        
                        if Behind && Behind4 <= 2
                            V_prec_4=V_prec_1;
                        end
                        
                        Matching_id=New_ordered_matching_sequences(o,1);
                        Vectors_new1_MAT=[V_prec_1 zeros(size(V_prec_1,1),1) signe angle_measured];
                        Vectors_new1_F=[V_prec_4 zeros(size(V_prec_4,1),1) signe angle_measured];
                        Vectors_new2_MAT=[V_prec_2 zeros(size(V_prec_1,1),1) signe angle_measured];
                        Vectors_new2_F=[V_prec_5 zeros(size(V_prec_4,1),1) signe angle_measured]; 
                        Vectors_new3_MAT=[V_prec_3 zeros(size(V_prec_1,1),1) signe angle_measured];
                        Vectors_new3_F=[V_prec_6 zeros(size(V_prec_4,1),1) signe angle_measured];
                        NN_array1(1,Matching_id)=Angles_New_xref3(Vectors_new1_MAT, Vectors_new1_F);
                        NN_array2(1,Matching_id)=Angles_New_xref3(Vectors_new2_MAT, Vectors_new2_F);
                        NN_array3(1,Matching_id)=Angles_New_xref3(Vectors_new3_MAT, Vectors_new3_F);
                    end
        NN_angles_1=[NN_angles_1;NN_array1];
        NN_angles_2=[NN_angles_2;NN_array2];
        NN_angles_3=[NN_angles_3;NN_array3];  
    
     else
         NN_angles_1=NaN;
         NN_angles_2=NaN;
         NN_angles_3=NaN;
     end
                   
end

B1=NN_angles_1<Threshold_Angle;
B2=NN_angles_2<Threshold_Angle;
B3=NN_angles_3<Threshold_Angle;

X_2=NN_array_T;X_2(1:size(X_2,1)+1:end)=NaN;
X_2_logical=X_2<Threshold_NN;X_2_double=double(X_2_logical);
X_2_double(find(~X_2_double))=NaN;

B_1=double(B1);B_1(find(~B_1))=NaN;
B_2=double(B2);B_2(find(~B_2))=NaN;
B_3=double(B3);B_3(find(~B_3))=NaN;
Delete1=B_3-B_2-B_1;Delete1(Delete1==-1)=1;NN_of_all_angles=Delete1; 

Delete=X_2_double-NN_of_all_angles;      
idmin_of_both_arrays=(Delete==0); 
[Row, COL]=find(idmin_of_both_arrays);[Rows_col_]=[Row COL];

%Merge fibres with NN arrays of distance and angles meetinf criteria
if size(Rows_col_,1)~=0    
        sequences = {};
            for row = Rows_col_' 
               hascommonvalue = cellfun(@(s) any(ismember(row, s)), sequences);
                   if any(hascommonvalue)
                      newmatch = unique([sequences{hascommonvalue}, row']); 
                      sequences(hascommonvalue) = [];
                      sequences{end+1} = newmatch; 
                   else
                      sequences{end+1} = row';
                   end
            end 
        sequences=sequences';
        [Xmatch] = cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [1])), sequences(:,1), 'UniformOutput', false);
        [Ymatch] = cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [2])),sequences(:, 1), 'UniformOutput', false);
        [ID_match]=cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [3])),sequences(:, 1), 'UniformOutput', false);
        [LocMatch]=cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [4])),sequences(:, 1), 'UniformOutput', false);
        Matching_=[Xmatch Ymatch ID_match LocMatch ];
        Mat_stitch=[Matching_];
        
        D2=[]; BP=[];E2=[]; Id_of_stitch=[];I=[];orientation=[];D2=[];
           for i=1:size(Mat_stitch, 1)
                BP=cell2mat(Mat_stitch(i,:));
                [~, orientation] = max([std(BP(:,1)),std(BP(:,2))]);
                    if orientation==1
                        D2=sortrows(BP, 1);
                    elseif orientation==2
                        D2=sortrows(BP, 2);
                    end
                E2=[E2;D2];
                Id_of_stitch=[repmat(i,length(BP), 1)];
                I=[I;Id_of_stitch]; 
            end
            
    New_IDS_from_I = accumarray(I(:,1),I(:,1),[],@(v){v});
    Tester_mat=cell2mat(New_IDS_from_I );
    E2(:,5)=Tester_mat;
    X_stitch_sorted = accumarray(E2(:,5),E2(:,1),[],@(v){v});
    X_stitch_sorted(any(cellfun(@isempty,X_stitch_sorted),2),:) = [];
    Y_stitch_sorted = accumarray(E2(:,5),E2(:,2),[],@(v){v}); 
    Y_stitch_sorted(any(cellfun(@isempty,Y_stitch_sorted),2),:) = [];
    IDS2_stitch_sorted=accumarray(E2(:,5),E2(:,3),[],@(v){v}); 
    IDS2_stitch_sorted(any(cellfun(@isempty,IDS2_stitch_sorted),2),:) = [];
    LocStitch_sorted=accumarray(E2(:,5),E2(:,4),[],@(v){v}); 
    LocStitch_sorted(any(cellfun(@isempty,LocStitch_sorted),2),:) = [];
    New_IDS_of_stitched_fibers=New_IDS_from_I;
    P_stitch_sorted=[X_stitch_sorted,Y_stitch_sorted,IDS2_stitch_sorted, New_IDS_of_stitched_fibers, LocStitch_sorted];%X Y and origonal IDS with ordering by x
    M_stitch=[];
    M_stitch=P_stitch_sorted; % x,y, old ID, new ID, localisations    
    Number_of_stitched_fibers=size(M_stitch,1);
end

if size(Rows_col_,1)==0
    Number_of_stitched_fibers=0;
    M_stitch=[];    
end


%Get fibres that are 'unique'
    Uni_fibers = 1:size(Mat_with_tracks_after_stitch_sorted,1);
    missingvalues=setdiff(Uni_fibers,unique(Rows_col_,'stable'))';
    missingvalues=num2cell(missingvalues);

if size(missingvalues,1)~=0
    [XValues_unique] = cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [1])), missingvalues(:,1), 'UniformOutput', false);
    [YValues3_unique] = cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [2])),missingvalues(:, 1), 'UniformOutput', false);
    [Id_Values3_unique] = cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [3])),missingvalues(:, 1), 'UniformOutput', false);    
    [Loc_Values_unique]=cellfun(@(rows) cell2mat(Mat_with_tracks_after_stitch_sorted(rows, [4])),missingvalues(:, 1), 'UniformOutput', false);
    Values_Uni=[XValues_unique YValues3_unique Id_Values3_unique Loc_Values_unique];
    P_unique=[Values_Uni]; %(x,y,oldID,localisation)
    
    D4=[];E4=[]; B4=[];orientation=[];
    for i=1:size(P_unique, 1)
        B4=cell2mat(P_unique(i,:));
        [~, orientation] = max([std(B4(:,1)),std(B4(:,2))]);
                    if orientation==1
                        D4=sortrows(B4, 1);
                    elseif orientation==2
                        D4=sortrows(B4, 2);
                    end
        E4=[E4;D4];
    end

    X_unique_sorted = accumarray(E4(:,3),E4(:,1),[],@(v){v});
    X_unique_sorted(any(cellfun(@isempty,X_unique_sorted),2),:) = [];
    Y_unique_sorted = accumarray(E4(:,3),E4(:,2),[],@(v){v}); 
    Y_unique_sorted(any(cellfun(@isempty,Y_unique_sorted),2),:) = [];
    IDS2_unique_sorted=accumarray(E4(:,3),E4(:,3),[],@(v){v}); 
    IDS2_unique_sorted(any(cellfun(@isempty,IDS2_unique_sorted),2),:) = [];
    LOC_unique_sorted=accumarray(E4(:,3),E4(:,4),[],@(v){v}); 
    LOC_unique_sorted(any(cellfun(@isempty,LOC_unique_sorted),2),:) = [];
    P_Unique_sorted=horzcat(X_unique_sorted,Y_unique_sorted,IDS2_unique_sorted,LOC_unique_sorted);
 
        M_unique=[];New_ID_unique=[];H2=[];
        for j=1:size(P_Unique_sorted,1)          
            x_values_unique_=P_Unique_sorted{j,1};
            y_values_unique_=P_Unique_sorted{j,2};
            Origional_IDs_unique=P_Unique_sorted{j,3};
            New_ID_unique=[repmat(j,length(x_values_unique_), 1)]  ; 
            H2=[H2;New_ID_unique];
        end
New_unique_IDS = accumarray(H2(:,1),H2(:,1),[],@(v){v});
M_unique=[P_Unique_sorted(:,1:3), New_unique_IDS P_Unique_sorted(:,4)]; %X,Y,OldID, NewID, LOC PREC
Number_of_unique_fibers=size(M_unique,1);
end
    if size(missingvalues, 1)==0 
        Number_of_unique_fibers=0;
        M_unique={};
    end

%Comine matricies of merged fibres and unique ones
Number_of_fibers=Number_of_stitched_fibers+Number_of_unique_fibers;
    if size(M_stitch,1)==0
        Maximum_id_of_stitch={0};
    end
    if size(M_stitch,1)~=0    
        Maximum_id_of_stitch=M_stitch(end,4);
    end
For_Addition=cell2mat(Maximum_id_of_stitch);
F_mean=mean(For_Addition);
    if size(M_unique,1)~=0
        Q=[];Q2=[];
        M_unique_to_extract_IDS=M_unique(:,4);
        for y=1:size(M_unique_to_extract_IDS,1)
            Q=cell2mat(M_unique_to_extract_IDS);
            Q2=Q+F_mean;
        end
     Q3=accumarray(Q2(:,1),Q2(:,1),[],@(v){v});
     Q3(any(cellfun(@isempty,Q3),2),:) = [];
     M_unique_for_extraction=[M_unique(:,1:3) Q3 M_unique(:,5)];
     P_fibers_all_to_extract=[M_stitch ; M_unique_for_extraction];
    end

    if size(M_unique,1)==0
      M_unique_to_extract_IDS ={};
      P_fibers_all_to_extract=[M_stitch];
    end
    
    M1=New_indicies_of_possible_unique_fibers;
    M2=cell2mat(missingvalues); 
    [col,~]=find(ismember(M1, M2));
    Unique_valuesID=M1(col, :);
    U=size(Unique_valuesID,1);
    OLDIDS=P_fibers_all_to_extract(:,3);
    All_old_ids={};
    for j=1:size(P_fibers_all_to_extract,1)
        Read_in=[];
        Read_in=({unique(OLDIDS{j,1},'stable')});

        All_old_ids=[All_old_ids;Read_in];
    end

    Indicies=[];
    for u=1:size(All_old_ids,1)
        mat_in=All_old_ids{u,1};
        S=size(mat_in,1);
        if U>=S
            [R,~]=find(ismember(Unique_valuesID, mat_in));
        end
        if U<S
            [R,~]=find(ismember(mat_in,Unique_valuesID));
        end
            if size(R,1)==0
                continue
            end
            if size(R,1)~=0
                Index_to_take=u;
            end
            Indicies=[Indicies;Index_to_take];
    end

New_indicies_of_fibers_to_never_be_stitched=Indicies;
%Input: x, y, id,  localisation, combined track
For_input=[P_fibers_all_to_extract(:,1:2),P_fibers_all_to_extract(:,4:5),P_fibers_all_to_extract(:,3)];
[Fiber_output_post_stitch]=Get_new_tracks(For_input);
end