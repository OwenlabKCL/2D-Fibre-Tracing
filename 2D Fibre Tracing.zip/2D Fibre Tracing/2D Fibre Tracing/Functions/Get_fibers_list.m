%Input: Radii_in,Input_for_tracing,Max,Angle_in
%Output: Matrix of possible identified fibres: x, y, ID, clock check (ignore),
%localisation precision
function [fibers_list]=Get_fibers_list(xmax,mat_crop,Max,angle_degrees)
 
angle=angle_degrees*pi/180;
datax2linearize=[];
datay2linearize=[];
datalr2linearize=[];
datax=[];
datay=[];
datalr=[];
dataloc=[];

 
data2linearize=mat_crop;
datax=data2linearize(:,1);
datay=data2linearize(:,2);
datalr=data2linearize(:,3);
dataloc=data2linearize(:,4);

 
MAXtp2linearize=[];
MAXx=[];
MAXy=[];
MAXtp=[];
MAXloc=[];

MAX2linearize=Max;
MAXx=MAX2linearize(:,1);
MAXy=MAX2linearize(:,2);
MAXtp=MAX2linearize(:,3);
MAXloc=MAX2linearize(:,4);
 
dataopt=[];
MAX2reduce=[];
dataopt=[datax datay datalr dataloc];
MAX2reduce=[MAXx MAXy MAXtp MAXloc];
S1=size(MAX2reduce);
S=S1(1);
MAX=[];
 
 
for i=1:S
   if MAX2reduce(i,1)~=0 & MAX2reduce(i,2)~=0
       MAX=[MAX; MAX2reduce(i,:)];
   end
end
%%% Order the max
I=[];
[B,I]=sort(MAX(:,3),'descend');
S1=size(MAX);
S=S1(1);
MAXordered=zeros(S,4);
 
for i=1:S
    MAXordered(i,:)=MAX(I(i),:);
end
 
% Main function body
n_points_above_sea_level1=size(dataopt);
n_points_above_sea_level=n_points_above_sea_level1(1);
 
Graphing=[];
 
for Radius=xmax
    
    fibers_list=[];
    second_mat=[];
    B=[];
    second_mat_=[];
    Fiber_list_=[];

    for i=1:S
    %%%%%%%%%%%%%%%%%%%%%%%% Initialisation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% for each max
    %First step for each max consists in ordering and keeping all points
    %closer than r
    structure=[];
    structure=[MAXordered(i,1:2) i 0 MAXordered(i,4)];
    points_of_interest1=[0 0 0 0];
    
    for j=1:n_points_above_sea_level
        d=sqrt((MAXordered(i,1)-dataopt(j,1))^2+(MAXordered(i,2)-dataopt(j,2))^2);
        if d<Radius && d~=0
            %Store them all for further usage
            points_of_interest1=[points_of_interest1; dataopt(j,:)];
        end
    end
    
    s1=size(points_of_interest1);
    s=s1(1);
    
    if s==1
       disp('Isolated max');
    else
        points_of_interest=[];
        points_of_interest=points_of_interest1(2:s,:);
        
        s=s-1;        
                              
        disp('Getting in the compass')
        
        point_of_int_vect_an=[];
        for j=1:s
        V_ref=[1 0];
        a=points_of_interest(j,1)-MAXordered(i,1);
        b=points_of_interest(j,2)-MAXordered(i,2);
        V=[a b];
        %scalar product
        scalar_product=V(1)*V_ref(1)+V(2)*V_ref(2);
        %Normes
        Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
        Norme_V=sqrt(V(1)^2+V(2)^2);
        %angle
        angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));
        signe=sign(a*b);
        if signe==0
            signe=1;
            angle_measured=0;
        end
        point_of_int_vect_an=[point_of_int_vect_an;points_of_interest(j,:) signe angle_measured];
        end
         
        Quadran_sum=[];
        Max_quadran=[0 0 0];
        q=pi/(2*angle);
        for z=1:floor(q)
            su=0;
            for j=1:s
            if point_of_int_vect_an(j,6)>=(z-1)*angle && point_of_int_vect_an(j,6)<(z)*angle && point_of_int_vect_an(j,5)>0
            su=su+point_of_int_vect_an(j,3);
            end
            if point_of_int_vect_an(j,6)<pi-(z-1)*angle && point_of_int_vect_an(j,6)>=pi-(z)*angle && point_of_int_vect_an(j,5)>0
            su=su+point_of_int_vect_an(j,3);
            end
            end
            Quadran_sum=[Quadran_sum; su z 100];
            if su>Max_quadran(1)
                Max_quadran=[su z 100];
            end
        end

 for z=1:floor(q)
            su=0;
            for j=1:s
            if point_of_int_vect_an(j,6)>=(z-1)*angle && point_of_int_vect_an(j,6)<(z)*angle && point_of_int_vect_an(j,5)<0
            su=su+point_of_int_vect_an(j,3);
            end
            if point_of_int_vect_an(j,6)<pi-(z-1)*angle && point_of_int_vect_an(j,6)>=pi-(z)*angle && point_of_int_vect_an(j,5)<0
            su=su+point_of_int_vect_an(j,3);
            end
            end
            Quadran_sum=[Quadran_sum; su z -100];
            if su>Max_quadran(1)
                Max_quadran=[su z -100];
            end
 end
 
 points_of_interest=[];
 
     if Max_quadran(3)>0
         for j=1:s
             if point_of_int_vect_an(j,6)>=(Max_quadran(2)-1)*angle && point_of_int_vect_an(j,6)<Max_quadran(2)*angle && point_of_int_vect_an(j,5)>0
                points_of_interest=[points_of_interest; point_of_int_vect_an(j,1:4)];
             end
             if point_of_int_vect_an(j,6)<pi-(Max_quadran(2)-1)*angle && point_of_int_vect_an(j,6)>=pi-Max_quadran(2)*angle && point_of_int_vect_an(j,5)>0
                points_of_interest=[points_of_interest; point_of_int_vect_an(j,1:4)];
             end
         end
     else
         for j=1:s
             if point_of_int_vect_an(j,6)>=(Max_quadran(2)-1)*angle && point_of_int_vect_an(j,6)<Max_quadran(2)*angle && point_of_int_vect_an(j,5)<0
                points_of_interest=[points_of_interest; point_of_int_vect_an(j,1:4)];
             end
             if point_of_int_vect_an(j,6)<pi-(Max_quadran(2)-1)*angle && point_of_int_vect_an(j,6)>=pi-Max_quadran(2)*angle && point_of_int_vect_an(j,5)<0
                points_of_interest=[points_of_interest; point_of_int_vect_an(j,1:4)];
             end
         end
     end
        
        w=size(points_of_interest);
        e=w(1);
        if e==0
            disp('in that annoying case')
        else
        
        I=[];
        [B,I]=sort(points_of_interest(:,3),'descend');
        sis=size(points_of_interest);
        s=sis(1);
        
        points_of_interest_ordered=zeros(s,4);
        for k=1:s
            points_of_interest_ordered(k,:)=points_of_interest(I(k),:);
        end
        
        %Here we start the structure with id i
        structure=[structure; points_of_interest_ordered(1,1:2) i 0 points_of_interest_ordered(1,4)];
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%MAIN ROUTINE%%%%%%%%%%%%%%%%%%%%%%%
        
        new_max=points_of_interest_ordered(1,1:2);
        a=new_max(1)-MAXordered(i,1);
        b=new_max(2)-MAXordered(i,2);
        V_prec=[a b];
        V_prec_av=V_prec;
        clock=1;
        FINISH=0;
        
        while FINISH==0
        points_of_interest_for_point_after_max=[];
        %%% Identifying points in the cone of interest
        for j=1:n_points_above_sea_level
        d=sqrt((new_max(1)-dataopt(j,1))^2+(new_max(2)-dataopt(j,2))^2);
        a=dataopt(j,1)-new_max(1);
        b=dataopt(j,2)-new_max(2);
        V=[a b];
        %scalar product
        scalar_product=V(1)*V_prec(1)+V(2)*V_prec(2);
        %Normes
        Norme_V_prec=sqrt(V_prec(1)^2+V_prec(2)^2);
        Norme_V=sqrt(V(1)^2+V(2)^2);
        %angle
        angle_measured=acos(scalar_product/(Norme_V_prec*Norme_V));
            
            if d<Radius && d~=0 && angle_measured<angle
                %Store them all for further usage
                angle_measured_normalized=abs(angle-angle_measured)/angle;
                points_of_interest_for_point_after_max=[points_of_interest_for_point_after_max; dataopt(j,:) angle_measured_normalized];
            end
        end
        w=size(points_of_interest_for_point_after_max);
        e=w(1);
        if e==0
            FINISH=1;
            disp('case no point')
        else
            %Find next point
            I=[];
            [B,I]=sort(points_of_interest_for_point_after_max(:,3),'descend');
            points_of_interest_for_point_after_max_ordered=zeros(e,5);
            for l=1:e
            points_of_interest_for_point_after_max_ordered(l,:)=points_of_interest_for_point_after_max(I(l),:);
            end
            prev_max=[];
            prev_max=new_max;
            
          
            Lr_normalized=[];
            Lr_normalized=points_of_interest_for_point_after_max_ordered;
            Lr_normalized(:,3)=points_of_interest_for_point_after_max_ordered(:,3)/points_of_interest_for_point_after_max_ordered(1,3);
            for l=1:e
                Lr_normalized(l,3)=Lr_normalized(l,3)*Lr_normalized(l,5);
            end
            
            I=[];
            [B,I]=sort(Lr_normalized(:,3),'descend');
            Lr_normalized_ordered=zeros(e,5);
            for l=1:e
            Lr_normalized_ordered(l,:)=Lr_normalized(I(l),:);
            end
            new_max=Lr_normalized_ordered(1,1:2);
          
            if clock<3
            a=new_max(1)-prev_max(1);
            b=new_max(2)-prev_max(2);
            V_prec=[a b];
            V_prec_av=[V_prec_av; V_prec];
            else
            V_prec_av(1,:)=[];
            a=new_max(1)-prev_max(1);
            b=new_max(2)-prev_max(2);
            V_prec=[a b];
            V_prec_av=[V_prec_av; V_prec];
            V_prec=[];
            V_prec=mean(V_prec_av);
            end
            clock=clock+1;
            %save in structure the next point
            structure=[structure; points_of_interest_for_point_after_max_ordered(1,1:2) i 0 points_of_interest_for_point_after_max_ordered(1,4)];
        end
        end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%Opposite direction%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
        new_max=points_of_interest_ordered(1,1:2);
        a=new_max(1)-MAXordered(i,1);
        b=new_max(2)-MAXordered(i,2);
        V_prec=[a b];
        V_prec_av=V_prec;
        clock=1;
        FINISH=0;
        zz=0;
        z=0;
        change_direction=1;
        
        while FINISH==0
        disp('2nd while/ opposite direction')
        points_of_interest_for_point_after_max=[];
 
        for j=1:n_points_above_sea_level
        if change_direction==1
            d=sqrt((MAXordered(i,1)-dataopt(j,1))^2+(MAXordered(i,2)-dataopt(j,2))^2);
            a=dataopt(j,1)-MAXordered(i,1);
            b=dataopt(j,2)-MAXordered(i,2);
        else
            d=sqrt((new_max(1)-dataopt(j,1))^2+(new_max(2)-dataopt(j,2))^2);
            a=dataopt(j,1)-new_max(1);
            b=dataopt(j,2)-new_max(2);
        end
        
 
        V=[a b];
        %scalar product
        scalar_product=V(1)*V_prec(1)+V(2)*V_prec(2);
        %Normes
        Norme_V_prec=sqrt(V_prec(1)^2+V_prec(2)^2);
        Norme_V=sqrt(V(1)^2+V(2)^2);
        %angle
        angle_measured=acos(scalar_product/(Norme_V_prec*Norme_V));
        if change_direction==1
            opp_angle=pi-angle;
            if d<Radius && d~=0 && angle_measured>opp_angle
                %Store them all for further usage
                angle_measured_normalized=1;
                points_of_interest_for_point_after_max=[points_of_interest_for_point_after_max; dataopt(j,:) angle_measured_normalized];
            end
        else
            if d<Radius && d~=0 && angle_measured<angle
                %Store them all for further usage
                angle_measured_normalized=abs(angle-angle_measured)/angle;
                points_of_interest_for_point_after_max=[points_of_interest_for_point_after_max; dataopt(j,:) angle_measured_normalized];
            end 
        end
        end
        change_direction=0;
        w=size(points_of_interest_for_point_after_max);
        e=w(1);
        if e==0
            FINISH=1;
            disp('case no point')
        else
            %Find next point
            I=[];
            [B,I]=sort(points_of_interest_for_point_after_max(:,3),'descend');
            points_of_interest_for_point_after_max_ordered=zeros(e,5);
            for l=1:e
            points_of_interest_for_point_after_max_ordered(l,:)=points_of_interest_for_point_after_max(I(l),:);
            end
            prev_max=[];
            if change_direction==1
                prev_max=MAXordered(i,1:2);
            else
                prev_max=new_max;
            end
            
            Lr_normalized=[];
            Lr_normalized=points_of_interest_for_point_after_max_ordered;
            Lr_normalized(:,3)=points_of_interest_for_point_after_max_ordered(:,3)/points_of_interest_for_point_after_max_ordered(1,3);
            for l=1:e
                Lr_normalized(l,3)=Lr_normalized(l,3)*Lr_normalized(l,5);
            end
            I=[];
            [B,I]=sort(Lr_normalized(:,3),'descend');
            Lr_normalized_ordered=zeros(e,5);
            for l=1:e
            Lr_normalized_ordered(l,:)=Lr_normalized(I(l),:);
            end
            new_max=Lr_normalized_ordered(1,1:2);
            if clock<3
            a=new_max(1)-prev_max(1);
            b=new_max(2)-prev_max(2);
            V_prec=[a b];
            V_prec_av=[V_prec_av; V_prec];
            else
            V_prec_av(1,:)=[];
            a=new_max(1)-prev_max(1);
            b=new_max(2)-prev_max(2);
            V_prec=[a b];
            V_prec_av=[V_prec_av; V_prec];
            V_prec=[];
            V_prec=mean(V_prec_av);
            end
            clock=clock+1;
            structure=[structure; points_of_interest_for_point_after_max_ordered(1,1:2) i 1 points_of_interest_for_point_after_max_ordered(1,4)];
        end
        end
        end
     end
fibers_list=[fibers_list; structure];
        

end
       
end

end
 

 
 
