%Inputs: x,y, id, loc, track
%output: Inputs: x,y, id, loc, track

function [Output_PP]=PostProcess(Fiber_output, After_branching_routine)

Make_new_IDS_all=[];num_sampling_points=10;M=[];All_locaisations=[];

for i=1:size(Fiber_output,1)  
    x_values_Stitch=Fiber_output{i,1};
    y_values_Stitch=Fiber_output{i,2};
    Old_ids=Fiber_output{i,3};
    origional_tracks=Fiber_output{i,5};
    U=unique(origional_tracks);
    xy_per_ID=[];
    xy_per_joining=[];
    Track_per_id=[];
    track_per_joining=[];
        for ii=1:size(x_values_Stitch,1)-1
            xy_per_joining=[linspace(x_values_Stitch(ii),x_values_Stitch(ii+1),num_sampling_points).'...
            linspace(y_values_Stitch(ii),y_values_Stitch(ii+1),num_sampling_points).']; 
            xy_per_ID=[xy_per_ID; xy_per_joining];
        end   
    Newly_assigned_IDS=[xy_per_ID,repmat(i,length(xy_per_ID), 1)];
    T=repmat(U,length(xy_per_ID),1);
    M=[M;Newly_assigned_IDS T ];

end


Artificial_points=M;
M_x= accumarray(M(:,3),M(:,1),[],@(v){v});
M_x(any(cellfun(@isempty,M_x),2),:) = [];
M_y= accumarray(M(:,3),M(:,2),[],@(v){v});
M_y(any(cellfun(@isempty,M_y),2),:) = [];
M_ID_artificial=accumarray(M(:,3),M(:,3),[],@(v){v});
M_ID_artificial(any(cellfun(@isempty,M_ID_artificial),2),:) = [];
M_tracks=accumarray(M(:,3),M(:,4),[],@(v){v});
M_tracks(any(cellfun(@isempty,M_tracks),2),:) = [];
Artificial_array=[M_x M_y M_ID_artificial M_tracks];% M_localisations];

%Here we have the points along the line drawn by the averaging.. we now
%want to compare these points to the other points in the origional
%matrix... 

NN_array=zeros(size(Artificial_array,1),1);
F_interest=[];mat_tempo=[]; 
     
for j=1:size(Artificial_array,1)
    F_interest=cell2mat(Artificial_array(j, 1:2));
    mat_tempo=cell2mat(After_branching_routine(j,1:2));
    NN_array(j,1)=Get_NND(F_interest, mat_tempo); 
end  

Merged_NN_values=[];
for m=1:size(NN_array, 1)
    X_in=NN_array(m,1);
    X_in={X_in};
    Merged_NN_values=[Merged_NN_values;X_in];
end

All_results1=[Fiber_output Merged_NN_values];
All_results=All_results1;
index = find([Merged_NN_values{:}]>60);
index=index';
All_results(index, :)=[];
New_ids=[];

for i=1:size(All_results, 1)
    X=All_results{i,1};
    S=size(X);
    Readin=repmat(i,[S(1),S(2)]);
    Cell_new_ids={Readin};
    New_ids=[New_ids;Cell_new_ids];
end
Output_PP=[];
Output_PP=[All_results(:,1:2), New_ids, All_results(:,4:5)];
end



