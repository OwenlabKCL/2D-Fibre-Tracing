function [CroppedData]=Angular_K_Function(OutputData,Ripley_radius)
%Inputs
%OutputData = Matrix of x, y, localisaiton uncertainty, Voronoi
%density parameter 
%Ripley Radius = Radius in nm of the search radius to perform an Angular
%Ripleys K over. 


%Output 
% CroppedData = Matrix of x, y, localisation uncertainty, Voronoi Density
% parameter, Modulation depth of the Angular K-function. Note that this
% matrix will be cropped dependant upon the Ripley radius of choice to
% account for edge effects in the calculation. 


LateralCropping = Ripley_radius;               % This will crop edges to compensate for edge effects. LateralCropping must be >=Ripley_radius. Default 200 nm.                                                
AngleIncrement = 5;                            % Angular increment (in degrees) to perform the analysis. Default = 5 degrees.
Shift = 0;                                     % 1 for True and 0 for False (depending on if you want to shift H(a) Values - default 1)


%% Main script 
Boundaries=[min(OutputData(:,1)), max(OutputData(:,1))...
    min(OutputData(:,2)), max(OutputData(:,2))];
AreaDataFull=(Boundaries(2)-Boundaries(1))*(Boundaries(4)-Boundaries(3));
xCoord = OutputData(:,1);
yCoord = OutputData(:,2);
NumberPointsFull = size(OutputData,1);

%Crop to the central region to ignore edge effects from Ripley Calculation 
Tested_X = [];
Tested_Y = [];

Logical_x=(OutputData(:,1)>=Boundaries(1)+LateralCropping) & (OutputData(:,1)...
    <=Boundaries(2)-LateralCropping);
Data_x_crop=OutputData(Logical_x,:);
Logical_y=(Data_x_crop(:,2)>=Boundaries(3)+LateralCropping) & (Data_x_crop(:,2)...
    <=Boundaries(4)-LateralCropping);
CroppedData1=Data_x_crop(Logical_y,:);
Tested_X=CroppedData1(:,1);
Tested_Y=CroppedData1(:,2);


AngleBins = 0:AngleIncrement:(360-AngleIncrement) ; AngleBins=AngleBins';
CumShiftedKValues = zeros(size(AngleBins,1),1);
AreaSegment = pi*(Ripley_radius^2)*AngleIncrement/360;

CumKValues=[];
All_H=[];

for j = 1:size(Tested_X,1)
        
        x = Tested_X(j);
        y = Tested_Y(j);
       
        r_xCoord = [];
        r_yCoord = [];
        tDistances = [];
          
       for h = 1:(NumberPointsFull-1)
          
                if h~=j
              
                xVar = xCoord(h);
                yVar = yCoord(h);
                tDistance = sqrt ((xVar-x)^2 + (yVar-y)^2);
                
                if tDistance < Ripley_radius
                    r_xCoord = [r_xCoord ; xVar];
                    r_yCoord = [r_yCoord ; yVar];
                    tDistances = [tDistances ; tDistance];
                end
                
                end
       end
       
       % Calculate angles of each vector with the reference vertical vector
       % of length Ripley_radius
       
       Angles = [];
       NormRef = Ripley_radius;
       
       for k = 1:size(r_xCoord);
           
           DotProduct = (r_yCoord(k)-y)*Ripley_radius;
           Norm = tDistances(k);
           
           % To avoid 'reflecting' the points in the left side of the circumference
           % onto the right one (same value of cosine) we convert from cos
           % to angle taking into account the x-position of each point with
           % respect to the x-position of the reference point
           
           if (r_xCoord(k)-x<=0)
               Angle = 360-(acos((DotProduct/(Norm*NormRef)))*180/pi);
           else
               Angle = acos((DotProduct/(Norm*NormRef)))*180/pi;
           end
           Angles = [Angles ; Angle];
       end
       
       KValues = [];
       
       for p = 1:size(AngleBins)
        
           Counter = 0;
           
           for l = 1:size(r_xCoord)
               if (AngleBins(p)<=Angles(l) && (AngleBins(p)+AngleIncrement)>Angles(l))
                   Counter = Counter + 1;
               end
           end
           
           KValue = Counter;
           KValues = [KValues ; KValue];
           
       end

NormalisedKValues = (360/AngleIncrement)*(AreaDataFull/(NumberPointsFull)*(KValues./size(Tested_X,1)));  
LValues = sqrt(NormalisedKValues/pi);
HValues = LValues-Ripley_radius;
HValues={HValues};
All_H=[All_H; HValues];

end
Mod=[];
All_depths=[];

for i=1:size(All_H,1)
    Read_in=All_H{i,1};
    Maximum=max(Read_in);
    Minimum=min(Read_in);
    Mod=Maximum-Minimum;
    All_depths=[All_depths;Mod];
end

CroppedData=[CroppedData1, All_depths];

end


