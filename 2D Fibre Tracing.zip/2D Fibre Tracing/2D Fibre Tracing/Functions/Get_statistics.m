
function [I]=Get_statistics(Size_ROI)

I=imread('Before_binarisation.tiff');
Binarised=im2bw(I,0.85);
Binarised_clear_border=imclearborder(Binarised);
BW=bwconncomp(Binarised_clear_border,8); 
Stats=regionprops(BW,'Area', 'Centroid','Perimeter','ConvexHull','ConvexArea'...
    ,'Eccentricity','EulerNumber','Orientation','PixelIdxList','PixelList');

Number_comps=BW.NumObjects;Centres=[];D=[];M_copy=[];Copy_area=[];Area=[];

if size(Stats,1)~=0
    
    for i=1:Number_comps
        Area(i,:)=Stats(i).Area;
        Perim(i,:)=Stats(i).Perimeter;
        Centres(i,:)=Stats(i).Centroid;
        Mean_mesh_area=mean(Area); 
    end
else
        Perim=[];
        Area=[];
        Centres=[];
end

figure;
imshow(Binarised_clear_border);
set(gca,'YDir','normal')
if size(Centres,1)~=0
    hold on
    scatter(Centres(:,1),Centres(:,2),50,'rx')
end

OutputName='After_binarisation';
OutputFolder=pwd;
print(gcf,'-dpng',fullfile(OutputFolder,[OutputName,'.png']));

%Calibrate image size to real nm size
calibrationFactor = Size_ROI/(size(Binarised,1)); %In nm
Perim_in_nm = Perim * calibrationFactor;
Area_sq_nm=Area *calibrationFactor.^2;

save('Stats_Pixels.mat','Stats');
save ('Enclosed_areas_nm_squared.mat', 'Area_sq_nm');
close all 

end



