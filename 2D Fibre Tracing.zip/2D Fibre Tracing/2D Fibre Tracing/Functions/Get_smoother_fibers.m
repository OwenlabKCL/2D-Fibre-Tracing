%Input Fiberoutput_before_smoothing: x,y,id,,localisation...track
%Output: P_all_averaged=x,y,ifd localisaiton
function [P_all_averaged]=Get_smoother_fibers(Fiber_output_post_stitch)

P_fibers_all_to_extract3=Fiber_output_post_stitch;
P_all=[];

for i=1:size(P_fibers_all_to_extract3,1)
    
    D=[];Copy_D=[];D2=[];D=cell2mat(P_fibers_all_to_extract3(i,:));
    Copy_D=D; D2=unique(Copy_D,'rows','stable');
    D3_x = accumarray(D2(:,3),D2(:,1),[],@(v){v}); 
    D3_x(any(cellfun(@isempty,D3_x),2),:) = [];
    D3_y = accumarray(D2(:,3),D2(:,2),[],@(v){v}); 
    D3_y(any(cellfun(@isempty,D3_y),2),:) = [];
    D3_i = accumarray(D2(:,3),D2(:,3),[],@(v){v}); 
    D3_i(any(cellfun(@isempty,D3_i),2),:) = [];
    D3_loc=accumarray(D2(:,3),D2(:,4),[],@(v){v}); 
    D3_loc(any(cellfun(@isempty,D3_loc),2),:) = [];  
    D3_track = accumarray(D2(:,3),D2(:,5),[],@(v){v}); 
    D3_track(any(cellfun(@isempty,D3_track),2),:) = [];
    P_u_new=[D3_x,D3_y,D3_i,D3_loc, D3_track];
    P_all=[P_all;P_u_new];
end 
D4=[];E4=[];B4=[];orientation=[];
for ii=1:size(P_all, 1)
    B4=cell2mat(P_all(ii,:));
    [~, orientation] = max([std(B4(:,1)),std(B4(:,2))]);
                if orientation==1
                    D4=sortrows(B4, 1);
                end

                if orientation==2
                    D4=sortrows(B4, 2);
                end
    E4=[E4;D4];
end

X_unique_sorted = accumarray(E4(:,3),E4(:,1),[],@(v){v});
X_unique_sorted(any(cellfun(@isempty,X_unique_sorted),2),:) = [];
Y_unique_sorted = accumarray(E4(:,3),E4(:,2),[],@(v){v}); 
Y_unique_sorted(any(cellfun(@isempty,Y_unique_sorted),2),:) = [];
IDS2_unique_sorted=accumarray(E4(:,3),E4(:,3),[],@(v){v}); 
IDS2_unique_sorted(any(cellfun(@isempty,IDS2_unique_sorted),2),:) = [];
LOC_unique_sorted=accumarray(E4(:,3),E4(:,4),[],@(v){v}); 
LOC_unique_sorted(any(cellfun(@isempty,LOC_unique_sorted),2),:) = [];
Track_unique_sorted=accumarray(E4(:,3),E4(:,5),[],@(v){v}); 
Track_unique_sorted(any(cellfun(@isempty,Track_unique_sorted),2),:) = [];
P_all_sorted=horzcat(X_unique_sorted,Y_unique_sorted,IDS2_unique_sorted,LOC_unique_sorted, Track_unique_sorted);
    
Cell_of_averagesx=[];Cell_of_averagesy=[];P_all_averaged=[];

for ij=1:size(P_all_sorted,1)
    
    Mat_x=P_all_sorted{ij,1};
    Mat_y=P_all_sorted{ij,2};
    Loc=P_all_sorted{ij,4};

%Call average function...     
[~,All_Averages_cellx,All_Averages_celly]=GetMovAve(Mat_x,Mat_y, 9, 4, 4); 
Cell_of_averagesx=[Cell_of_averagesx; All_Averages_cellx];
Cell_of_averagesy=[Cell_of_averagesy; All_Averages_celly];
end
Averages=[];
Averages=[Cell_of_averagesx, Cell_of_averagesy];P_all_averaged=[];
P_all_averaged=[Averages, P_all_sorted(:,3:4)]; %x,y,id,localisation... 
end
