
function [Average_NND]=Get_NND(F_interest, mat_tempo)

dist_tempo=[];
for ii=1:size(F_interest,1)
    init=0;
    for jj=1:size(mat_tempo,1)
        dist_tempo1=sqrt((F_interest(ii,1)-mat_tempo(jj,1))^2+(F_interest(ii,2)-mat_tempo(jj,2))^2);
    if init==0
            min1=dist_tempo1;
            init=1;
    end
    if dist_tempo1<min1
        min1=dist_tempo1;
    end
    end
    dist_tempo=[dist_tempo min1];       
end
Average_NND=mean(dist_tempo);
