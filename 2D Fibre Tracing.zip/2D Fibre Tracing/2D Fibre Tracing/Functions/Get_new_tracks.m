 
%Input: x, y, id,  localisation, combined track,
%Output: x,y, id, localisation,  track

function [Output]=Get_new_tracks(P_with_tracks_after_stitch_sorted)
New_matrix=[];
New_matrix=P_with_tracks_after_stitch_sorted; %x,y, new id  old track localisation.... 
distance_segment=[];
All_tracks=[];
distances=[];

for j=1:size(New_matrix,1)
     Output=[];X_coordinate=[];Y_coordinate=[];All_Vectors=[];Vector=[];           
     Matrix_x=New_matrix{j,1};
     Matrix_y=New_matrix{j,2};
     Matrix_IDS=New_matrix{j,3};
  
     if size(Matrix_x,1)==0
      Track_length_per_fiber={[]};   
      Sum_of_distances=NaN;         
     end
    
     if size(Matrix_x,1)~=0      
          for i=1:size(Matrix_x,1)
                            Sum_of_distances=[]; 
                            X_coordinate=Matrix_x(i);
                            Y_coordinate=Matrix_y(i);
                            Vector=[X_coordinate;Y_coordinate];
                            All_Vectors=[All_Vectors, Vector];
                            angle_measured=[]; d=[]; e=[];         
                            All_distance_segments_per_ID=[];
                            
                        for m=1:size(All_Vectors, 2)-1        
                                d=All_Vectors(1,m+1)-All_Vectors(1,m);
                                e=All_Vectors(2,m+1)-All_Vectors(2,m);
                                distance_segment=sqrt(d^2+e^2);
                                All_distance_segments_per_ID=[All_distance_segments_per_ID;distance_segment];
                                Sum_of_distances=sum(All_distance_segments_per_ID);
                        end      
              Track_length_per_fiber=repmat(Sum_of_distances,size(Matrix_x,1),1);
              Track_length_per_fiber={Track_length_per_fiber};              
          end  
     end    
 distances=[distances;Track_length_per_fiber];
end  
Output=[New_matrix(:,1:4),distances];
end
 
 
 
 
 