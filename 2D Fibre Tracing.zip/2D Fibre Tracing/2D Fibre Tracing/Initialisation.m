%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               Initialisation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Full cell data file required in the format of x, y, localisation
%precision. 

%User definable parameters
MainDirectory=(''); %Directory with full cell file 
ROI_Centres=[0,0; 0,0];%Centres of the ROIs required for analysis from the full cell file
Ripley_radius=200;                             %Radius to perform Angular Ripley's K-function - default 200
Size_ROI_required=3000;                        % Enter ROI size desired                                                               
%End of user definables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



Size_ROI=3000 + (2*Ripley_radius); % ROI size desired, +2*Ripley radiusto counter edge effects.    
cd(MainDirectory);
%Import data and define columns - requires a csv file with x, y,
%localisation as columns 1,2,3 - import ignores first row of headers.
[Fname, Pname]=uigetfile('*.csv');
filename=fullfile(Pname, Fname);
assert(exist(filename,'file')==2, '%s does not exist.', filename);
Path=strcat(Pname,Fname);
data=csvread(filename, 1, 0);        

warndlg('Close if the data selected is the full data file','Warning!')

if size(data, 2)~=3
    disp('Error, three columns are not specified')
 return
end

x=data(:,1);
y=data(:,2);
loc=data(:,3);
Boundaries=[min(data(:,1)), max(data(:,1)), min(data(:,2)), max(data(:,2))];
    
%Tesselation of raw data
[Voronoi_verticies, Voronoi_cells]=voronoin([x, y]);

%Find ROI of interest  
Number_of_ROIS=size(ROI_Centres,1);

%Crop the ROIs defined by ROI_centres and save as text files
for k=1:Number_of_ROIS
    
 cd(MainDirectory);
 folder=num2str(k);
 mkdir(folder)
 cd(fullfile(MainDirectory, folder));
 mat1=(data(:,1)<=ROI_Centres(k,1)+(Size_ROI./2) & data(:,1)>=ROI_Centres(k,1)-(Size_ROI./2));
 xlogic=data(mat1,:);
 mat2=(xlogic(:,2)<=ROI_Centres(k,2)+(Size_ROI./2) & xlogic(:,2)>=ROI_Centres(k,2)-(Size_ROI./2));
 Region=xlogic(mat2,:);
 dlmwrite('centre.txt',ROI_Centres(k,:));
 dlmwrite('Region.txt', Region,'precision',10);
 
end

%Obtain tesselated ROIs
for j=1:Number_of_ROIS
    
   cd(MainDirectory) 
   FolderName=num2str(j);
   cd(fullfile(MainDirectory,FolderName));
   ROI_Centre=ROI_Centres(j,:);
   ROI_X=ROI_Centre(1);ROI_Y=ROI_Centre(2);
   
   if ROI_X-(Size_ROI./2)<Boundaries(1) | ROI_X+(Size_ROI./2)>Boundaries(2)...
           | ROI_Y-(Size_ROI./2)<Boundaries(3) | ROI_Y+(Size_ROI./2)>...
           Boundaries(4) 
         Error_J_loop= ['Error - Folder',[num2str(j)],...
             '...Selected ROI outside of data bounds'];
         disp (Error_J_loop)
         cd(MainDirectory);

     continue 
   else 
       
    Logical_x=false(size(Voronoi_cells, 1),size(Voronoi_cells,2));
    Logical_x=(data(:,1)<=ROI_X+(Size_ROI./2) & data(:,1)...
            >=ROI_X-(Size_ROI./2));
    X_Data=data(Logical_x,:);
    Voronoi_x_cells=Voronoi_cells(Logical_x,:);
    Logical_y=false(size(X_Data, 1),size(X_Data,2));
    Logical_y=(X_Data(:,2)<=ROI_Y+(Size_ROI./2) & X_Data(:,2)...
            >=ROI_Y-(Size_ROI./2));
    Voronoi_xy_cells=Voronoi_x_cells(Logical_y,:);
    XY_Data=X_Data(Logical_y,:);
    
    Density_parameter_ROI=[];
    
    for h = 1:size(Voronoi_xy_cells,1);
         ind = Voronoi_xy_cells{h}';
         Tesselated_area_ROI=polyarea(Voronoi_verticies(ind,1), ...
             Voronoi_verticies(ind,2));
         Density_parameter=Tesselated_area_ROI(:,1).^(-0.5);
         Density_parameter_ROI=[Density_parameter_ROI;Density_parameter];
         
    end
    Tesselated_ROI_Data=[XY_Data, Density_parameter_ROI];
    
    %Generate CSR equivalent for thresholding 
    NPoints_perROI=size(XY_Data,1);
    Density_required=NPoints_perROI./(Size_ROI.^2); %Per nm^2
    Big_CSR_Area=Size_ROI*2;
    Number_CSR_points_required=round((Big_CSR_Area.^2)*Density_required);
    Coord_CSR_randomised = Big_CSR_Area*rand(Number_CSR_points_required,2);
    Uncertainty_CSR=sqrt(2)*round(mean(loc))*rand(Number_CSR_points_required,1);
    CSR_map=[Coord_CSR_randomised Uncertainty_CSR];
    [CSR_Verticies, CSR_Cells]=voronoin([CSR_map(:,1), CSR_map(:,2)]);
    
    %Take central region to avoid the edge effects of Voronoi Tesselation
    Big_CSR_Area_centre=Size_ROI;
    Logical_x_CSR=false(size(CSR_Cells, 1),size(CSR_Cells,2));
    Logical_x_CSR=(CSR_map(:,1)<=Big_CSR_Area_centre+(Size_ROI./2) & CSR_map(:,1)...
            >=Big_CSR_Area_centre-(Size_ROI./2));
    X_Data_CSR=CSR_map(Logical_x_CSR,:);
    Voronoi_x_cells_CSR=CSR_Cells(Logical_x_CSR,:);

    Logical_y_CSR=false(size(X_Data_CSR, 1),size(X_Data_CSR,2));
    Logical_y_CSR=(X_Data_CSR(:,2)<=Big_CSR_Area_centre+(Size_ROI./2) & X_Data_CSR(:,2)...
            >=Big_CSR_Area_centre-(Size_ROI./2));
    Voronoi_xy_cells_CSR=Voronoi_x_cells_CSR(Logical_y_CSR,:);
    XY_Data_CSR=X_Data_CSR(Logical_y_CSR,:);
    
    Density_parameter_ROI_CSR=[];
    for m = 1:size(Voronoi_xy_cells_CSR,1);
          ind = Voronoi_xy_cells_CSR{m}';
          Tesselated_area_ROI_CSR=polyarea(CSR_Verticies(ind,1),...
              CSR_Verticies(ind,2));
          Density_parameter_ROI_CSR1=Tesselated_area_ROI_CSR(:,1).^(-0.5);
          Density_parameter_ROI_CSR=[Density_parameter_ROI_CSR;Density_parameter_ROI_CSR1];
          
    end
    Average_CSR_Density_Parameter=mean(Density_parameter_ROI_CSR);
    
    %Keep only data points with a density parameter >= the average CSR
    %value
    
    Data_above_threshold=false(size(Tesselated_ROI_Data,1),1);
    Data_above_threshold=Tesselated_ROI_Data(Tesselated_ROI_Data(:,4)>=...
        Average_CSR_Density_Parameter,:);

   end   
   
   
   %Angular K function to determine most fibrous points post-tesselation
   [Modulations]=Angular_K_Function(Data_above_threshold,Ripley_radius);
   [Max]=Get_initial_points(50,Modulations); 
   Input_for_tracing=[Modulations(:,1:2),Modulations(:,4),Modulations(:,3)];
   Max_ordered=[Max(:,1:2),Max(:,4),Max(:,3)];
    
   dlmwrite('Input_for_tracing.txt', Input_for_tracing,'precision',10);
   dlmwrite('Max.txt', Max_ordered,'precision',10);
   

end
