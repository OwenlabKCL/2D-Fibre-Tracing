%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              Main Routine                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%User Definable Parameters
MainDirectory=('Y:\Sabrina\Codes for Github'); 
cd(MainDirectory);                           
Number_of_ROIS=2;           %Number of ROIs in the main folder
Radii_in=100;               %Radius of cone search nm 
Angle_in=15;                %Half angle of the cone search degrees 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%E

for n=1:Number_of_ROIS
    
   cd(MainDirectory);
   Foldername1=num2str(n);
   cd(fullfile(MainDirectory, Foldername1));
   Max=[]; Input_for_tracing=[];
   Max=importdata('Max.txt');
   Input_for_tracing=importdata('Input_for_tracing.txt');
   Threshold_Angle=15;         %Angle for post processing checking co-linearity
   Threshold_NN=30;            %Nearest neighbour distance for post processing checking co-linearity
   Colinear_branch_threshold=5;%Check if fibres are co-linear or branched 
   r_of_search=60;             %Radius for identifying possible branching fibres
  %Run cone search (Radii_in, Angle_in) to determine the fibre IDs.      
  [fibers_list]=Get_fibers_list(Radii_in,Input_for_tracing,Max,Angle_in);   
  %Find the length of each fibre trace
  [Matrix1]= Get_Fibre_Tracks(fibers_list);
         
   if size(Matrix1{1,1})~=0
         P1=Matrix1; 
         New_matrix=[P1(:,1:3),P1(:,5)]; 
         P_with_tracks=[New_matrix, P1(:,4)]; %x, y, id, localisation, track
         [Mat_with_tracks_after_stitch_sorted]=Get_longest_track(P_with_tracks);
         Full_matrix1=Mat_with_tracks_after_stitch_sorted;
         Mat_with_tracks_after_stitch_sorted={[]};
         
          %Iteratively search for fibres that could be merged according to
          %angular and radial restriants from their starting positions         
           All_Matched_Indicies_Start=[];
           for mm=1:size(Full_matrix1,1)
               Fiber_id=mm;
               if size(Mat_with_tracks_after_stitch_sorted{mm,1},1)==0 && mm>1
                   continue
               else
                   if mm==1
                     [Mat_with_tracks_after_stitch_sorted, Indicies_first_loop]=Iterative_function...
                         (Fiber_id,Full_matrix1, r_of_search,Colinear_branch_threshold);
                   else
                     [P_with_tracks_after_stitch_sorted2, Indicies_first_loop]=Iterative_function...
                         (Fiber_id,Mat_with_tracks_after_stitch_sorted, r_of_search,Colinear_branch_threshold);
                     Mat_with_tracks_after_stitch_sorted={};
                     Mat_with_tracks_after_stitch_sorted=P_with_tracks_after_stitch_sorted2;
                     P_with_tracks_after_stitch_sorted2={};
                   end  
               end
            All_Matched_Indicies_Start=[All_Matched_Indicies_Start;Indicies_first_loop];
           end
           
            All_Matched_Indicies_Start=unique(All_Matched_Indicies_Start,'rows','stable');
            if size(All_Matched_Indicies_Start,1)~=0
                Diff_mat1=[All_Matched_Indicies_Start(:,1);All_Matched_Indicies_Start(:,2)];
            else
                Diff_mat1=[];
            end
            
            Diff_mat1=unique(Diff_mat1,'stable');
            Max_value=[];
            Max_value=size(Full_matrix1,1);
            Uni_fibers = 1:Max_value;
            missingvalues=setdiff(Uni_fibers,Diff_mat1)';
            missingvalues=num2cell(missingvalues);
            M=cell2mat(missingvalues); %Look for fibres that have not been matched
            [Mat_with_tracks_after_stitch_sorted]=Get_new_tracks...
                (Mat_with_tracks_after_stitch_sorted);%Get new tracks after first merge

            
          %Iteratively search for fibres that could be merged according to
          %angular and radial restriants from their terminating positions 
          Mat_with_tracks_after_stitch_sorted_end={[]};
          All_Matched_indicies_end=[];
           for mp=1:size(Mat_with_tracks_after_stitch_sorted,1)
               Fiber_id=mp;
               if size(Mat_with_tracks_after_stitch_sorted_end{mp,1},1)==0 && mp>1
                   continue
               else
                   if mp==1
                  [Mat_with_tracks_after_stitch_sorted_end,Test_All_indicies_end]=Iterative_function_end(Fiber_id,Mat_with_tracks_after_stitch_sorted, r_of_search,Colinear_branch_threshold);
                   else
                   [Mat_with_tracks_after_stitch_sorted_end2, Test_All_indicies_end]=Iterative_function_end(Fiber_id,Mat_with_tracks_after_stitch_sorted_end, r_of_search,Colinear_branch_threshold);
                   Mat_with_tracks_after_stitch_sorted_end={};
                   Mat_with_tracks_after_stitch_sorted_end=Mat_with_tracks_after_stitch_sorted_end2;
                   Mat_with_tracks_after_stitch_sorted_end2={};
                   end  
               end
               All_Matched_indicies_end=[All_Matched_indicies_end;Test_All_indicies_end];
           end
           
            %Look for fibres that have not been matched
            All_Matched_indicies_end=unique(All_Matched_indicies_end,'rows','stable');
            Diff_mat1=[];
            if size(All_Matched_indicies_end,1)~=0
                Diff_mat1=[All_Matched_indicies_end(:,1);All_Matched_indicies_end(:,2)];
            else
                Diff_mat1=[];
            end
            Uni_fibers = 1:Max_value;
            missingvalues2=setdiff(Uni_fibers,Diff_mat1)';
            missingvaluesend=num2cell(missingvalues2);
            M2=cell2mat(missingvaluesend);
           [col,X]=find(ismember(M, M2));Unique_valuesID=M(col, :);
           %Get new fibre lengths post merging
            [Mat_with_tracks_after_stitch_sorted_end]=Get_new_tracks(Mat_with_tracks_after_stitch_sorted_end);
            
            Copy_end=Mat_with_tracks_after_stitch_sorted_end;
            Remaining_IDS=1:1:size(Copy_end,1); Remaining_IDS=Remaining_IDS';
            Ids_full=num2cell(Remaining_IDS);
            Copy_end(:,6)=Ids_full;    
            Copy_end(any(cellfun(@isempty,Copy_end),2),:) = [];
            New_indicies_of_possible_unique_fibers=find(ismember(cell2mat(Copy_end(:,6)),Unique_valuesID));
            [Fiber_output_post_stitch,New_indicies_of_fibers_to_never_be_stitched]=Get_NN_stitch_new(Copy_end, Threshold_Angle,Threshold_NN,New_indicies_of_possible_unique_fibers);
            Fiber_output_post_stitch(New_indicies_of_fibers_to_never_be_stitched,:)=[];
           
            %Get final descriptions
            if size(Fiber_output_post_stitch,1)~=0
                    New_ids={};
                    for n=1:size(Fiber_output_post_stitch,1)
                        Read_in=size(Fiber_output_post_stitch{n,1},1);
                        ID=repmat(n,Read_in, 1);
                        ID={ID};
                        New_ids=[New_ids;ID];
                    end
                    Fiber_output_post_stitch(:,3)=New_ids;
                    [P_all_averaged]=Get_smoother_fibers(Fiber_output_post_stitch); %   Output: x, y, id , localisation
                    [Fiber_output]=Get_new_tracks(P_all_averaged);
                    [Output_PP]=PostProcess(Fiber_output, Fiber_output_post_stitch);
                    save Output_PP.mat Output_PP
            else
                    Output_PP={[]};
                    save Output_PP.mat Output_PP
            end
   else
                 Output_PP={[]};
                 save Output_PP.mat Output_PP
   end
   
   clearvars -except MainDirectory Number_of_ROIS Radii_in Angle_in Threshold_Angle Threshold_NN Colinear_branch_threshold r_of_search
      
end
