%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               Get final descriptors from Output 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%User Definable Parameters
MainDirectory=('Y:\Sabrina\Codes for Github'); %Directory with ROIs within
Number_of_ROIS=2;                  %Number of ROIs 
Ripley_radius=200;                 %Radius of Angular Ripley's K-function used
Size_ROI_required=3000;                     % Enter ROI size    
Figure=1;                          %Figure of traces option, 1=true,0=false                                                             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd(MainDirectory);
for n=1:Number_of_ROIS
     cd(MainDirectory)
     Foldername1= num2str(n);
     cd(fullfile(MainDirectory, Foldername1));
     data_detected=[];
     Detected=[];
     data_detected=load('Output_PP');
     Detected=data_detected.Output_PP;

         if size(Detected{1,1},1) == 0
            Binarised_map={[]};
            Fibre_list={[]};
            Branching_angles={[]};
            Branched_coords={[]};
            Number_branches={[]};
         else                     
           [Fibre_list]=Get_new_tracks(Detected); %Check fibre lengths are all complete
           [Branch_angles, Branch_coordinates,Number_of_branching_points]=Get_branch_descriptors(Fibre_list,Size_ROI_required,Ripley_radius);
           [Binarised_map]=Binarise(Fibre_list, Ripley_radius, Figure); %Get area infos
           [I]=Get_statistics(Size_ROI_required);
         end
                     
     save Final_list.mat Fibre_list         %Fibre list : x, y, ID, localisation precision, Fibre length
     save Branch_angles.mat Branch_angles
     dlmwrite('Branch_coordinates.txt',Branch_coordinates,'precision',10);
     save Number_of_branching_points.mat Number_of_branching_points
     clear  Final_list Branch_angles  Branch_coordinates Number_of_branching_points        
 
end
