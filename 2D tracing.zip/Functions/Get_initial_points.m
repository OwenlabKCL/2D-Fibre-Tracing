function[Max]=Get_initial_points(r,mat)
  %Input r=search radius to define max over
  %      mat=matrix with x, y, localisation uncertainty, Voronoi density
  %      parameter, Modulation depth assessed by Angular K function
  
  %Output Max = matrix of x, y, localisation uncertainty, Voronoi density
  %parameter
  
  num_mat1=size(mat);
  num_mat=num_mat1(1);
  
  if num_mat==1;
        disp('Only one data point - Error')
        Max=[];
  end
  
  if num_mat>1;
    num_points=size(mat,1);
    mat_tempo=zeros(num_points,6);
  
    index=0;
    mat_tempo=mat;
    Max=zeros(1,4);
  
  for i=1:num_points;
      
        for y=1:num_points;
          Distance_squared=(mat_tempo(i,1)-mat_tempo(y,1))^2+(mat_tempo(i,2)-mat_tempo(y,2))^2;
          mat_tempo(y,6)=sqrt(Distance_squared);
        end

            MAX=true;
    
            for j=1:num_points;

              if mat_tempo(j,6)<r && mat_tempo(j,5)>mat_tempo(i,5) && i~=j;
                MAX=false;
                break
              end
              if mat_tempo(j,6)<r && mat_tempo(j,5)==mat_tempo(i,5) && i~=j && j<i;
                MAX=false;
                break
              end

              end
    
    if MAX==true && mat_tempo(i,5)>0;
      if index==0;
        
        Max=mat_tempo(i,1:5);
        index=index+1;
      else
        Max=[Max; mat_tempo(i,1:5)];
        
      end 
    end
  end
  end
  
  
  if index==0;
    Max=[];
  end
 Max=Max(:,1:4);
end
  

