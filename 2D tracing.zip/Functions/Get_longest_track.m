%Input : Matrix of x, y, id, localisation, track.
%Output: Ordered matrix by descending track length: x, y, id, localisation, track 
function [Sorted_by_track_length]=Get_longest_track(Ordered_matrix_origional_tracks)
Start_end_points_fibres=[];
Matrix_to_accume=[];

  for i=1:size(Ordered_matrix_origional_tracks,1)
      Matrix_to_sort=[];Copy_Mat=[];   
      Fibre_interest=Ordered_matrix_origional_tracks(i,:);
      Matrix_to_sort=cell2mat(Fibre_interest);
      Copy_Mat=Matrix_to_sort;
      [~, orientation] = max([std(Copy_Mat(:,1)),std(Copy_Mat(:,2))]);
                   
          if orientation==1
             Matrix_sorted=sortrows(Copy_Mat, 1);
          elseif orientation==2
             Matrix_sorted=sortrows(Copy_Mat, 2);
          end

      Matrix_sorted1=unique(Matrix_sorted, 'rows','stable'); %Incase the same point assigned twice. 
      Fiber_start_x=Matrix_sorted1(1,1);
      Fiber_start_y=Matrix_sorted1(1,2);
      Fiber_end_x=Matrix_sorted1(end,1);
      Fiber_end_y=Matrix_sorted1(end, 2);
       
       Matrix_to_accume=[Matrix_to_accume;Matrix_sorted];
       Start_end_points_fibres=[Start_end_points_fibres;Fiber_start_x...
           , Fiber_start_y, Fiber_end_x,Fiber_end_y];        

   end

     x_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,1),[],@(v){v});
     x_1(any(cellfun(@isempty,x_1),2),:) = [];
     y_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,2),[],@(v){v});
     y_1(any(cellfun(@isempty,y_1),2),:) = [];
     id_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,3),[],@(v){v});
     id_1(any(cellfun(@isempty,id_1),2),:) = [];
     Loc_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,4),[],@(v){v});
     Loc_1(any(cellfun(@isempty,Loc_1),2),:) = [];
     Track_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,5),[],@(v){v});
     Track_1(any(cellfun(@isempty,Track_1),2),:) = [];
     Organised_data=[x_1, y_1, id_1,Loc_1,Track_1];

     Tracks_ordered=unique(cell2mat([id_1, Track_1]),'rows','stable');
     Descending_tracks_ids=sortrows(Tracks_ordered,-2);    %Sort in descending order.
     Sorted_by_track_length=Organised_data(Descending_tracks_ids(:,1),:);

     %Re-intitalise Ids
      New_ID=[];
      for e=1:size(Sorted_by_track_length,1)
           Size_in=size(Sorted_by_track_length{e,3});
           Assigned_id={repmat(e,[Size_in, 1])};
           New_ID=[New_ID;Assigned_id];
      end
      
       Sorted_by_track_length(:,3)=New_ID;
       Start_end_points_fibres(:,5)=unique(cell2mat(New_ID),'stable'); %Add new id column for each fibre 

end
