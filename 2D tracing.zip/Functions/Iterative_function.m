%Input: x,y,id,localisation, track
%Output: x,y,id localisation track

function [Matrix_4, All2]=Iterative_function(Fiber_id,Full_matrix, r_of_search,Colinear_branch_threshold)

%Find initial points of each fibre of interest.
[Start_end_point_fibre_of_interest,Matrix_4]=Get_start_end_points(Fiber_id,Full_matrix);

%Initialise
No_match=0;
Ind=1;
Size_of_sequences=size(Full_matrix,1);
clock=0;
Concatenate=0;
Match=0;
All2=[];


while 0<=Size_of_sequences
    
  Current_ID=Fiber_id;
  
  if No_match==0 
       %Identify fibers that could be co-linear. 
        Ind=1; 
        Close_events=[];All_under_consideration_1=[];All_points_1=[];New_matrix={};
        
        Matrix=cell2mat(Matrix_4); 
        x_of_full_fiber=Matrix_4{Fiber_id,1};
        y_of_full_fiber=Matrix_4{Fiber_id,2};
        id_of_full_fiber=Matrix_4{Fiber_id,3};
       
        x_start=Start_end_point_fibre_of_interest(1,1);
        y_start=Start_end_point_fibre_of_interest(1,2);
        id_start=Fiber_id(1,1);   

        %Creates bounding square for speed rather than ones further away
        %from threshold
        xrow2=(Matrix(:,1)>=x_start-500) & (Matrix(:,1)<=x_start+500);
        output_x2 = Matrix(xrow2,:);
        yrow2=(output_x2(:,2)>=y_start-500) & (output_x2(:,2)<=y_start+500);
        Close_events= output_x2(yrow2,:);
        Number_points=size(Close_events, 1);
        
        %Check for proximal fibres to the start points of all other fibers,
        %Identify them all and later check if they are colinear by imposing
        %a colinear angle threshold.
        r_xCoord = []; r_yCoord = [];Id_coord=[];
        tDistances = [];
        
             for h = 1:Number_points
                      if Close_events(h,3)~=Fiber_id
                         xVar = Close_events(h,1);
                         yVar = Close_events(h,2);
                         IDVar=Close_events(h,3);
                         tDistance = sqrt ((xVar-x_start)^2 + (yVar-y_start)^2);
                                if tDistance < r_of_search
                                    r_xCoord = [r_xCoord ; xVar];
                                    r_yCoord = [r_yCoord ; yVar];
                                    Id_coord=[Id_coord;IDVar];
                                    tDistances = [tDistances ; tDistance]; 
                                end
                      end   
             end 

             R_x_={};R_y_=[];Enclosed_id=[];

             if size(tDistances,1) == 0
                        r_xCoord=x_of_full_fiber;R_x_={r_xCoord};
                        r_yCoord=y_of_full_fiber; R_y_={r_yCoord};
                        Id_coord=id_of_full_fiber;
                        ID_coord_of_enclosed={Id_coord};        
                        ID_of_current_fiber=repmat(id_start, [size(r_xCoord,1),1]);
                        ID_of_current_fibercell={ID_of_current_fiber};
                        Enclosed_id=[Enclosed_id;ID_of_current_fibercell];
                        All_points_1=[R_x_,R_y_, Enclosed_id, ID_coord_of_enclosed];

             elseif size(tDistances,1)~=0
                         R_x_={r_xCoord}; R_y_={r_yCoord}; ID_coord_of_enclosed={Id_coord};
                         ID_of_current_fiber=repmat(id_start, [size(r_xCoord,1),1]);
                         ID_of_current_fibercell={ID_of_current_fiber};
                         Enclosed_id=[Enclosed_id;ID_of_current_fibercell];
                         All_points_1=[R_x_, R_y_,Enclosed_id, ID_coord_of_enclosed];
             end

            All_under_consideration_1=[All_under_consideration_1;All_points_1]; %x,y, id of current fibre, ids of possibly matching fibres.
            NN_all_1=[]; NN_all_2=[];NN_all_3=[];Ordered_matching_sequences=[];
            Size_of_sequences=[]; Fibre_interest=[]; 

            Current_id=cell2mat(All_under_consideration_1(1,3));
            Matching_ids=cell2mat(All_under_consideration_1(1,4));
            Matching_ids_sequence=unique(Matching_ids,'stable');
            

            if size(All_under_consideration_1{1,1},1)~=0
                Subtraction=Matching_ids-Current_id;
            end

            if size(All_under_consideration_1{1,1},1)==0
                NN_array1=NaN(size(All_under_consideration_1, 1),1)';
                NN_array2=NaN(size(All_under_consideration_1, 1),1)';
                NN_array3=NaN(size(All_under_consideration_1, 1),1)';
                break
            end

            if sum(Subtraction)==0
                    NN_array1=NaN(size(All_under_consideration_1, 1),1)';
                    NN_array2=NaN(size(All_under_consideration_1, 1),1)';
                    NN_array3=NaN(size(All_under_consideration_1, 1),1)';
                    Ordered_matching_sequences=0;
                    New_ordered_matching_sequences=0;

                    break
            end

  else
        Subtraction=1;
        No_match=0;
        clock=1;
  end

 
   %If there is a match to be made...    
    if sum(Subtraction)~=0
            if clock==0
               Matching_ids_sequence(Matching_ids_sequence==Current_ID)=[];
               Tracks=Matrix_4(Matching_ids_sequence,5);
               Id_of_biggest_track=Matrix_4(Matching_ids_sequence,3);
               All_tracks=[Id_of_biggest_track, Tracks];
               Matrix_Tracks=cell2mat(All_tracks);
               [~,col]=max(Matrix_Tracks(:,2));
               ID=Matrix_Tracks(col, 1);
               X=sortrows(Matrix_Tracks,-2);
               Ordered_matching_sequences=unique(X(:,1),'stable');
               Size_of_sequences=size(Ordered_matching_sequences,1);
               New_ordered_matching_sequences=Ordered_matching_sequences(1,1);
            else
                clock=0;
            end
           
           Begin_coord_current_id=Start_end_point_fibre_of_interest(1,1:2);
           End_coord_current_id=Start_end_point_fibre_of_interest(1,3:4);
           
           NN_array1=NaN(size(Start_end_point_fibre_of_interest,1),1)';
           NN_array2=NaN(size(Start_end_point_fibre_of_interest,1),1)';
           NN_array3=NaN(size(Start_end_point_fibre_of_interest,1),1)';
            
           Fiber_end_x=[];Fiber_start_x=[];Fiber_start_y=[];Fiber_end_y=[];
           Fibre_interest=[Begin_coord_current_id Current_ID; End_coord_current_id Current_ID];
           F_interest_full=cell2mat(Matrix_4(Current_ID, :));
           
            
                    for o=1:size(New_ordered_matching_sequences,1)                       
                        mat_for_directionality=[];V_prec_1=[]; V_prec_2=[];
                        V_prec_3=[];V_prec_4=[];V_prec_5=[]; V_prec_6=[];
                        a=[];b=[];a2=[];b2=[];a3=[];b3=[];a4=[];b4=[];
                        a5=[]; b5=[];a6=[];b6=[];mat_tempo=[];
                        mat_tempo1=[];F_interest_chopped=[];
                        
                        mat_tempo1=cell2mat(Matrix_4(New_ordered_matching_sequences(o,1),1:3));
                        mat_tempo=unique(mat_tempo1, 'rows','stable');%Corresponding possible colinear matches
                        
                        %Check still in the correct order
                        To_order=mat_tempo;
                        [~, orientation] = max([std(To_order(:,1)),std(To_order(:,2))]);
                        
                          if orientation==1
                               mat_tempo=sortrows(To_order, 1);
                          elseif  orientation==2
                               mat_tempo=sortrows(To_order, 2);
                          end
                        
                        %Find minimum distances from the fibre of interest
                        %to the possible co-linear fibre.
                        
                        distance_tempo=[];
                        Distances=[];
                                for ii=1:size(Fibre_interest,1)
                                    init=0;
                                    dist_tempo1=[];
                                    for jj=1:size(mat_tempo,1)
                                        dist_tempo1=sqrt((Fibre_interest(ii,1)-mat_tempo(jj,1))^2+(Fibre_interest(ii,2)-mat_tempo(jj,2))^2);
                                        Distances=[Distances;dist_tempo1];
                                        if init==0
                                            min1=dist_tempo1;
                                            init=1;   
                                        end
                                        if dist_tempo1<min1
                                            min1=dist_tempo1;  
                                        end
                                    end
                                    distance_tempo=[distance_tempo; min1];
                                end
   
                     S=size(mat_tempo,1);S2=size(Distances,1);
                     Split_to_size1=Distances(1:S,:);
                     Split_to_size2=Distances(S+1:end,:);
                     [Row_begin, ~]=find(Split_to_size1==distance_tempo(1,1));
                     Row_begin=Row_begin(1,1);
                     [Row_end,~]=find(Split_to_size2==distance_tempo(2,1));
                     Row_end=Row_end(1,1);

                    % If there are less than 10 points to the trace keep
                    % the entire trace as the estimation of directionality.
                    if S<=10  
                        mat_for_directionality=mat_tempo;
                    end
                    
                    %If there are more points to consider, 
                    %Take the established trace to determine angles. 
                    if S>10
                            if Row_begin==Row_end   
                                Distance_from_end=S-Row_begin;
                                Difference_to_make_upto10=10-Distance_from_end;                               
                                    if Distance_from_end>=10
                                         mat_for_directionality=mat_tempo(Row_begin:Row_begin+10,:);
                                    end  
                                        if Distance_from_end<10
                                                  if Distance_from_end~=0
                                                        if Row_begin-Difference_to_make_upto10~=0
                                                             mat_for_directionality=mat_tempo(Row_begin-Difference_to_make_upto10:S,:);
                                                        end
                                                        if Row_begin-Difference_to_make_upto10==0
                                                          mat_for_directionality=mat_tempo(Row_begin-Difference_to_make_upto10+1:S,:);
                                                        end
                                                  end
                                                  if Distance_from_end==0
                                                     mat_for_directionality=mat_tempo(Row_begin-Difference_to_make_upto10+1:S,:); 
                                                  end
                                        end                    
                            end 
                           
                           if Row_begin~=Row_end                               
                               Difference_between_rows=abs(Row_begin-Row_end);                  
                               if Difference_between_rows >= 10
                                        if Row_begin < Row_end
                                               mat_for_directionality=mat_tempo(Row_begin:Row_end,:);
                                        end
                                           if Row_begin >Row_end
                                               mat_for_directionality=mat_tempo(Row_end:Row_begin,:);
                                           end                       
                               end
                                 
                               if Difference_between_rows<10
                                   if Row_end < Row_begin
                                       Row_end1=Row_end;
                                       Row_end=Row_begin;
                                       Row_begin=Row_end1; 
                                   end
                                      
                               Difference_to_make_upto10=10-Difference_between_rows;
                               Difference_behind=abs(1-Row_begin);
                               Distance_to_end=S-Row_end;
                               Difference_to_add=abs(Distance_to_end-Difference_to_make_upto10);
                                   
                                           if Distance_to_end >= 10
                                               mat_for_directionality=mat_tempo(Row_begin:Row_begin+10,:);   
                                           end

                                           if Distance_to_end < 10 
                                                    if Difference_behind >=10   
                                                        mat_for_directionality=mat_tempo(Row_end-10:Row_end,:);
                                                    end
                                                    
                                                    if Difference_behind <10  
                                                       mat_for_directionality=mat_tempo;
                                                    end
                                           end
                               end  
                           end
                    end
                       
                        %Repeat for fibres of interest
  
                        mat_chopped1=[];
                        mat_chopped2=[];
                        mat_chopped1=mat_for_directionality(1,:);
                        mat_chopped2=mat_for_directionality(end,:);
                        F_tempo=[mat_chopped1;mat_chopped2];
                        
                        mat_tempo31=F_interest_full(:,1:3);
                        mat_tempo3=unique(mat_tempo31,'rows','stable');
                        
                        To_order=[];
                        To_order=mat_tempo3;
                        [~, orientation] = max([std(To_order(:,1)),std(To_order(:,2))]);

                          if orientation==1
                               mat_tempo3=sortrows(To_order, 1);
                          end

                          if orientation==2
                               mat_tempo3=sortrows(To_order, 2);
                          end
                        
                         dist_tempo3=[];
                         D4=[];
                                for ii=1:size(F_tempo,1)
                                    init=0;
                                    dist_tempo2=[];
                                    for jj=1:size(mat_tempo3,1)
                                        dist_tempo2=sqrt((F_tempo(ii,1)-mat_tempo3(jj,1))^2+(F_tempo(ii,2)-mat_tempo3(jj,2))^2);
                                        D4=[D4;dist_tempo2];
                                        if init==0
                                            min2=dist_tempo2;
                                            init=1;   
                                        end
                                        if dist_tempo2<min2
                                            min2=dist_tempo2;  
                                        end
                                    end
                                    dist_tempo3=[dist_tempo3; min2];
                                end                           
                                
                     S4=size(mat_tempo3,1);
                     Start_point_split_mat=D4(1:S4,:);
                     End_point_splitf=D4(S4+1:end,:);

                     [Row_begin2, ~]=find(Start_point_split_mat==dist_tempo3(1,1));
                     [Row_end2,~]=find(End_point_splitf==dist_tempo3(2,1));
                     Row_begin2=Row_begin2(1,1);
                     Row_end2=Row_end2(1,1);
                     S4=size(mat_tempo3,1);

                    if S4<=10  
                      F_interest_chopped=mat_tempo3;
                    end

                    if S4>10
                          if Row_begin2==Row_end2 
                                Distance_from_end=S4-Row_begin2;
                                Difference_to_make_upto10=10-Distance_from_end;
                                if Distance_from_end>=10  
                                     F_interest_chopped=mat_tempo3(Row_begin2:Row_begin2+10,:);
                                end  
                                
                                if Distance_from_end<10
                                          if Distance_from_end~=0
                                                if Row_begin2-Difference_to_make_upto10~=0
                                                     F_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10:S4,:);
                                                end
                                                if Row_begin2-Difference_to_make_upto10==0
                                                  F_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10+1:S4,:);
                                                end 
                                          end
                                          if Distance_from_end==0
                                             F_interest_chopped=mat_tempo3(Row_begin2-Difference_to_make_upto10+1:S4,:); 
                                          end
                                end                   
                                
                         end 
   
                           if Row_begin2~=Row_end2 
                               Difference_between_rows=abs(Row_begin2-Row_end2);
                               if Difference_between_rows >= 10
                                        if Row_begin2 < Row_end2
                                               F_interest_chopped=mat_tempo3(Row_begin2:Row_end2,:);
                                        end
                                        if Row_begin2 >Row_end2
                                               F_interest_chopped=mat_tempo3(Row_end2:Row_begin2,:);
                                        end
                               end
                               
                               if Difference_between_rows<10
                                   if Row_end2 < Row_begin2
                                       Row_end1=Row_end2;
                                       Row_end2=Row_begin2;
                                       Row_begin2=Row_end1;
                                   end
                                   
                               Difference_to_make_upto10=10-Difference_between_rows;
                               Difference_behind=abs(1-Row_begin2);
                               Distance_to_end=S4-Row_end2;
                                   
                                           if Distance_to_end >= 10
                                               F_interest_chopped=mat_tempo3(Row_begin2:Row_begin2+10,:);   
                                           end

                                           if Distance_to_end < 10 
                                                    if Difference_behind >= 10
                                                        F_interest_chopped=mat_tempo3(Row_end2-10:Row_end2,:);
                                                    end
                                                    if Difference_behind < 10 
                                                        F_interest_chopped=mat_tempo3;
                                                    end
                                           end
                               end
                       end    
                    end
                        
                       %Has to be done for each iteration of new sequences.....    
                       %Get angle of F_interest .... 
                        Mat_sorted=[];
                        Mat_sorted_1=[];
                        Mat_sorted_1=unique(F_interest_chopped, 'rows','stable');
                        
                        % Take the 80% to the end... 
                        M_1=floor(0.8*size(Mat_sorted_1,1));
                        Difference_percentage=size(Mat_sorted_1,1)-M_1;
                        D_over_2=floor(Difference_percentage./2);
                        d_2=mod(Difference_percentage,2);
                        Mat_sorted1=[];
                        
                        if d_2==1 && D_over_2~=0%%number is odd
                            Mat_sorted1=Mat_sorted_1(D_over_2:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2~=0 %number is even
                            Mat_sorted1=Mat_sorted_1(D_over_2:end-D_over_2,:);   
                        end
                         if d_2==1 && D_over_2==0%%number is odd
                            Mat_sorted1=Mat_sorted_1(1:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2==0 %Number is even
                            Mat_sorted1=Mat_sorted_1(1:end-D_over_2,:);   
                        end
                        
                        Mat_sorted=Mat_sorted1;                         
                        Percentage1=20;
                        Percentage2=50;
                        Percentage3=75;
                        
                        %If the trace is small, then take the full vector
                        if size(Mat_sorted, 1) <=7
                             Behind=2;
                             Fiber_start_x=Mat_sorted(1,1);
                             Fiber_start_y=Mat_sorted(1,2);
                             Fiber_end_x=Mat_sorted((end),1);
                             Fiber_end_y=Mat_sorted((end),2);
                             a=Fiber_end_x-Fiber_start_x;
                             b=Fiber_end_y-Fiber_start_y;
                             V_prec_1=[a b];
                             V_ref=[1 0];
                             signe=sign(a*b);
                             scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                             Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                             Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                             angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V)); 
                             V_prec_2=V_prec_1;
                             V_prec_3=V_prec_1;
                             
                        end
                        
                        %%% Get the 3 percentage vectors to estimate directionality     
                        if size(Mat_sorted,1)>7  
                            %First 20%
                            Number_of_points_per_fiber1=size(Mat_sorted,1);
                            To_take=Number_of_points_per_fiber1*(Percentage1./100);
                            Behind=ceil(To_take);
                            Fiber_start_x=Mat_sorted(1,1);
                            Fiber_start_y=Mat_sorted(1,2);
                            Fiber_end_x=Mat_sorted((Behind),1);
                            Fiber_end_y=Mat_sorted((Behind),2);
                            a=Fiber_end_x-Fiber_start_x;
                            b=Fiber_end_y-Fiber_start_y;
                            V_prec_1=[a b];
                            V_ref=[1 0];
                            signe=sign(a*b);
                            scalar_product=V_prec_1(1)*V_ref(1)+V_prec_1(2)*V_ref(2);
                            Norme_V_ref=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V=sqrt(V_prec_1(1)^2+V_prec_1(2)^2);
                            angle_measured=acos(scalar_product/(Norme_V_ref*Norme_V));

                            %50% of trace
                            To_take2=Number_of_points_per_fiber1*(Percentage2./100);
                            Behind2=ceil(To_take2);
                            Fiber_start_x2=Mat_sorted(1,1);
                            Fiber_start_y2=Mat_sorted(1,2);
                            Fiber_end_x2=Mat_sorted((Behind2),1);
                            Fiber_end_y2=Mat_sorted((Behind2),2);
                            a2=Fiber_end_x2-Fiber_start_x2;
                            b2=Fiber_end_y2-Fiber_start_y2;
                            V_prec_2=[a2 b2];
                            signe=sign(a2*b2);
                            V_ref=[1 0];
                            scalar_product2=V_prec_2(1)*V_ref(1)+V_prec_2(2)*V_ref(2);
                            Norme_V_ref2=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V2=sqrt(V_prec_2(1)^2+V_prec_2(2)^2);
                            angle_measured2=acos(scalar_product2/(Norme_V_ref2*Norme_V2));
                            
                            %75% of trace
                            To_take3=Number_of_points_per_fiber1*(Percentage3./100);
                            Behind3=ceil(To_take3);
                            Fiber_start_x3=Mat_sorted(1,1);
                            Fiber_start_y3=Mat_sorted(1,2);
                            Fiber_end_x3=Mat_sorted((Behind3),1);
                            Fiber_end_y3=Mat_sorted((Behind3),2);
                            a3=Fiber_end_x3-Fiber_start_x3;
                            b3=Fiber_end_y3-Fiber_start_y3;
                            V_prec_3=[a3 b3];
                            V_ref=[1 0];
                            signe=sign(a3*b3);
                            scalar_product3=V_prec_3(1)*V_ref(1)+V_prec_3(2)*V_ref(2);
                            Norme_V_ref3=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V3=sqrt(V_prec_3(1)^2+V_prec_3(2)^2);
                            angle_measured3=acos(scalar_product3/(Norme_V_ref3*Norme_V3));         
                        end

                        %Repeat
                        Mat_sorted_chopped_1=[];
                        Mat_sorted_chopped_1=unique(mat_for_directionality, 'rows','stable');
                        M_2=floor(0.8*size(Mat_sorted_chopped_1,1));
                        Difference_percentage=size(Mat_sorted_chopped_1,1)-M_2;
                        D_over_2=floor(Difference_percentage./2);
                        d_2=mod(Difference_percentage,2);
                        Mat_sorted_chopped1=[];
                        
                        if d_2==1 && D_over_2~=0%%number is odd
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(D_over_2:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2 ~=0 %Number is even
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(D_over_2:end-D_over_2,:);   
                        end
                         if d_2==1 && D_over_2==0%%number is odd
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(1:end-1-D_over_2,:);
                        end
                        if d_2==0 && D_over_2 ==0 %Number is even
                            Mat_sorted_chopped1=Mat_sorted_chopped_1(1:end-D_over_2,:);   
                        end  
                        Mat_sorted_chopped=Mat_sorted_chopped1;
                        
                        %%% Get the 3 percentage vectors to estimate directionality     
                        if size(Mat_sorted_chopped, 1) <=7
                             Behind4=2;
                             Fiber_start_x4=Mat_sorted_chopped(1,1);
                             Fiber_start_y4=Mat_sorted_chopped(1,2);
                             Fiber_end_x4=Mat_sorted_chopped((end),1);
                             Fiber_end_y4=Mat_sorted_chopped((end),2);
                             a4=Fiber_end_x4-Fiber_start_x4;
                             b4=Fiber_end_y4-Fiber_start_y4;
                             V_prec_4=[a4 b4];
                             V_ref=[1 0];
                             signe=sign(a*b);
                             scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                             Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                             Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                             angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));                    
                             V_prec_5=V_prec_4;
                             V_prec_6=V_prec_4;       
                        end
                        
                        if size(Mat_sorted_chopped,1)>7
                            %20% of trace
                            Number_of_points_per_fiber4=size(Mat_sorted_chopped,1);
                            To_take4=Number_of_points_per_fiber4*(Percentage1./100);
                            Behind4=ceil(To_take4);
                            Fiber_start_x4=Mat_sorted_chopped(1,1);
                            Fiber_start_y4=Mat_sorted_chopped(1,2);
                            Fiber_end_x4=Mat_sorted_chopped((Behind4),1);
                            Fiber_end_y4=Mat_sorted_chopped((Behind4),2);
                            a4=Fiber_end_x4-Fiber_start_x4;
                            b4=Fiber_end_y4-Fiber_start_y4;
                            V_prec_4=[a4 b4];
                            V_ref=[1 0];
                            signe=sign(a4*b4);
                            scalar_product4=V_prec_4(1)*V_ref(1)+V_prec_4(2)*V_ref(2);
                            Norme_V_ref4=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V4=sqrt(V_prec_4(1)^2+V_prec_4(2)^2);
                            angle_measured4=acos(scalar_product4/(Norme_V_ref4*Norme_V4));

                            %50% of trace
                            To_take5=Number_of_points_per_fiber4*(Percentage2./100);
                            Behind5=ceil(To_take5);
                            Fiber_start_x5=Mat_sorted_chopped(1,1);
                            Fiber_start_y5=Mat_sorted_chopped(1,2);
                            Fiber_end_x5=Mat_sorted_chopped((Behind5),1);
                            Fiber_end_y5=Mat_sorted_chopped((Behind5),2);
                            a5=Fiber_end_x5-Fiber_start_x5;
                            b5=Fiber_end_y5-Fiber_start_y5;
                            V_prec_5=[a5 b5];
                            V_ref=[1 0];
                            signe=sign(a5*b5);
                            scalar_product5=V_prec_5(1)*V_ref(1)+V_prec_5(2)*V_ref(2);
                            Norme_V_ref5=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V5=sqrt(V_prec_5(1)^2+V_prec_5(2)^2);
                            angle_measured5=acos(scalar_product5/(Norme_V_ref5*Norme_V5));
                            
                            %75% of trace
                            To_take6=Number_of_points_per_fiber4*(Percentage3./100);
                            Behind6=ceil(To_take6);
                            Fiber_start_x6=Mat_sorted_chopped(1,1);
                            Fiber_start_y6=Mat_sorted_chopped(1,2);
                            Fiber_end_x6=Mat_sorted_chopped((Behind6),1);
                            Fiber_end_y6=Mat_sorted_chopped((Behind6),2);
                            a6=Fiber_end_x6-Fiber_start_x6;
                            b6=Fiber_end_y6-Fiber_start_y6;
                            V_prec_6=[a6 b6];
                            V_ref=[1 0];
                            signe=sign(a6*b6);
                            scalar_product6=V_prec_6(1)*V_ref(1)+V_prec_6(2)*V_ref(2);
                            Norme_V_ref6=sqrt(V_ref(1)^2+V_ref(2)^2);
                            Norme_V6=sqrt(V_prec_6(1)^2+V_prec_6(2)^2);
                            angle_measured6=acos(scalar_product6/(Norme_V_ref6*Norme_V6));
                        end
                        
                        if Behind && Behind4 <= 2
                            V_prec_4=V_prec_1;
                        end
                        
                        Matching_id=New_ordered_matching_sequences(o,1);
                        Vectors_new1_MAT=[V_prec_1 zeros(size(V_prec_1,1),1) signe angle_measured];
                        Vectors_new1_F=[V_prec_4 zeros(size(V_prec_4,1),1) signe angle_measured]; 
                        Vectors_new2_MAT=[V_prec_2 zeros(size(V_prec_1,1),1) signe angle_measured];
                        Vectors_new2_F=[V_prec_5 zeros(size(V_prec_4,1),1) signe angle_measured]; 
                        Vectors_new3_MAT=[V_prec_3 zeros(size(V_prec_1,1),1) signe angle_measured];
                        Vectors_new3_F=[V_prec_6 zeros(size(V_prec_4,1),1) signe angle_measured];                      
                        NN_array1(1,Matching_id)=Angles_New_xref3(Vectors_new1_MAT, Vectors_new1_F);
                        NN_array2(1,Matching_id)=Angles_New_xref3(Vectors_new2_MAT, Vectors_new2_F);
                        NN_array3(1,Matching_id)=Angles_New_xref3(Vectors_new3_MAT, Vectors_new3_F);
                        
                    end
      
    NN_all_1=[NN_all_1;NN_array1];
    NN_all_2=[NN_all_2;NN_array2];
    NN_all_3=[NN_all_3;NN_array3];  
 
    B1=[];B2=[];B3=[];
    B1=NN_all_1<=Colinear_branch_threshold;
    B2=NN_all_2<=Colinear_branch_threshold;
    B3=NN_all_3<=Colinear_branch_threshold;
    B_1=double(B1); B_1(find(~B_1))=NaN;
    B_2=double(B2); B_2(find(~B_2))=NaN;
    B_3=double(B3);B_3(find(~B_3))=NaN;
    Delete=B_3-B_2-B_1;
    Delete(Delete==-1)=1;
    NN_of_all_angles=Delete; 

    Index_to_consider=New_ordered_matching_sequences;
    New_id_to_give=[];
    All_to_take=[];
    To_take_all_match=[];
    Indicies_of_stitch1=[];
    
    if New_ordered_matching_sequences ~=0
        if NN_of_all_angles(1,Index_to_consider)==1
            Match=1;
            No_match=0;
            To_take1=Fiber_id;
            To_take2=Index_to_consider ;
            T={};
            T{1,1}(1)=To_take1;
            T{1,1}(2)=To_take2; 
            Indicies_of_stitch1=[Indicies_of_stitch1; Fiber_id To_take2];
            Indicies_of_stitch=Indicies_of_stitch1;

                if Concatenate==0
                    Concatenate=1;
                    Xmatch=cellfun(@(rows) cell2mat(Full_matrix(rows, [1])), T(:,1), 'UniformOutput', false);
                    Ymatch = cellfun(@(rows) cell2mat(Full_matrix(rows, [2])),T(:,1), 'UniformOutput', false);
                    old_ID_match=cellfun(@(rows) cell2mat(Full_matrix(rows, [3])),T(:,1), 'UniformOutput', false);
                    Track_match=cellfun(@(rows) cell2mat(Full_matrix(rows, [5])),T(:, 1), 'UniformOutput', false);
                    LocMatch=cellfun(@(rows) cell2mat(Full_matrix(rows, [4])),T(:, 1), 'UniformOutput', false);
                    Matching=[Xmatch Ymatch old_ID_match  LocMatch Track_match];
                else
                    Xmatch=cellfun(@(rows) cell2mat(Matrix_4(rows, [1])), T(:,1), 'UniformOutput', false);
                    Ymatch = cellfun(@(rows) cell2mat(Matrix_4(rows, [2])),T(:,1), 'UniformOutput', false);
                    old_ID_match=cellfun(@(rows) cell2mat(Matrix_4(rows, [3])),T(:,1), 'UniformOutput', false);
                    Track_match=cellfun(@(rows) cell2mat(Matrix_4(rows, [5])),T(:, 1), 'UniformOutput', false);
                    LocMatch=cellfun(@(rows) cell2mat(Matrix_4(rows, [4])),T(:, 1), 'UniformOutput', false);
                    Matching=[Xmatch Ymatch old_ID_match  LocMatch Track_match];
                end

                Size_0=size(Matching{1,1},1);
                New_id_to_give=repmat(Fiber_id, Size_0, 1);
                New_id={New_id_to_give};
                New_matrix=[Matching(:,1:2) New_id_to_give,  LocMatch , Track_match];
                MATRIX=cell2mat(New_matrix);
                Check_size=size(MATRIX, 1); 
                Matrix_4(Fiber_id,:)=New_matrix;
                Matrix_4(To_take2,:)={[]}; 
                All2=[All2;Indicies_of_stitch];
            end
        

                 if NN_of_all_angles(1, Index_to_consider)~=1
                   Ordered_matching_sequences(1,:)=[];
                   Size_of_sequences=size(Ordered_matching_sequences,1);
                   No_match=1;
                   Ind=Ind+1;
                   if Size_of_sequences==0
                      break    
                   end

                end

    end
 
 end

end

All_not_stitch1=[];
if Match==0
    Not_stitched=Fiber_id;
    All_not_stitch1=[All_not_stitch1; Not_stitched];
end

end

