function [dist_tempo]=Angles_New_xref3(F_interest, mat_tempo)
  dist_tempo=[];    
for iq=1:size(F_interest,1)
       Degrees_angle1=[];
        for jm=1:size(mat_tempo,1)
                Signe_1=[];Signe_2=[];Angle_1=[]; Angle_2=[];
                V_prec=[];V=[]; angle_measured=[];Theta1=[];Theta2=[];
              
                V_prec1=F_interest(iq,1:2);
                V1=mat_tempo(jm,1:2);  
                Signe_1=sign(V_prec1(1)*V_prec1(2));
                Signe_2=sign(V1(1)*V1(2));
                
                V_prec=[V_prec1, 0, Signe_1 ];
                V_prec_abs=abs(V_prec); 
                V=[V1 0 Signe_2];
                V_abs=abs(V);
                
                  if V_prec(:,4)==0                     
                        [~,col]=find(V_prec1==0);      
                        if col==2
                            %Y is zero - completely horizontal fiber
                            Angle_1=0;
                            Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                            angle_measured=Angle_2+Angle_1;
                            Degrees_angle1=(angle_measured*180)./pi;
                        
                        end
                        if col==1
                            Angle_1=pi./2;    
                            %Have to now consider quardrant cases.... 
                            Signe_1test1=sign(V_prec1);
                            [~,col1]=find(Signe_1test1==0);
                             Signe_1test1(:,col1)=[];
                            True_sine=Signe_1test1;
                            V_prec(:,4)= True_sine;
                             %++ first.
                            if V_prec(:,4)==1 && V(:,4)==1
                                Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                                angle_measured=pi-Angle_1-Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;

                            end         
                             if V_prec(:,4)==-1 && V(:,4)==-1
                                Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                                angle_measured=pi-Angle_1-Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;
                             end 
                            if V_prec(:,4)==1 && V(:,4)==-1
                                 Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                                angle_measured=Angle_1+Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;  
                            end
                            if V_prec(:,4)==-1 && V(:,4)==1
                                Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                                angle_measured=Angle_1+Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;  
                            end               
                        end    
                  end
                  
                       if V(:,4)==0                                       
                        [~,col]=find(V1==0);    
                        if col==2
                            %Y is zero - completely horizontal fiber
                            Angle_1=0;
                            Angle_2=atan(V_prec_abs(:,2)./V_prec_abs(:,1));
                            angle_measured=Angle_2+Angle_1;
                            Degrees_angle1=(angle_measured*180)./pi;
                        end
                        if col==1
                            Angle_1=pi./2;   
                            %Have to now consider quardrant cases....  
                            Signe_1test2=sign(V1);
                            [~,col]=find(Signe_1test2==0);
                            Signe_1test2(:,col)=[];
                            True_sine=Signe_1test2;
                            V(:,4)=True_sine;
                             %++ first.
                            if V_prec(:,4)==1 && V(:,4)==1
                                Angle_2=atan(V_prec_abs(:,2)./V_prec_abs(:,1));
                                angle_measured=pi-Angle_1-Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;
                            end
                             if V_prec(:,4)==-1 && V(:,4)==-1
                                Angle_2=atan(V_prec_abs(:,2)./V_prec_abs(:,1));
                                angle_measured=pi-Angle_1-Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;
                             end  
                            if V_prec(:,4)==1 && V(:,4)==-1
                                 Angle_2=atan(V_prec_abs(:,2)./V_prec_abs(:,1));
                                angle_measured=Angle_1+Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;  
                            end
                            if V_prec(:,4)==-1 && V(:,4)==1
                                Angle_2=atan(V_prec_abs(:,2)./V_prec_abs(:,1));
                                angle_measured=Angle_1+Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;  
                            end      
                        end 
                       end             
                           if V_prec(:,4)==1 && V(:,4)==1
                                Angle_1=atan(V_prec_abs(:,2)./V_prec_abs(:,1));      
                                Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                                Theta1=pi-Angle_1;
                                Theta2=pi-Angle_2;
                                angle_measured=abs(Theta1-Theta2);
                                Degrees_angle1=(angle_measured*180)./pi;
                           end
                             if V_prec(:,4)==-1 && V(:,4)==-1
                                Angle_1=atan(V_prec_abs(:,2)./V_prec_abs(:,1));      
                                Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                                Theta1=pi-Angle_1;
                                Theta2=pi-Angle_2;
                                angle_measured=abs(Theta1-Theta2);
                                Degrees_angle1=(angle_measured*180)./pi;
                             end
                            if V_prec(:,4)==1 && V(:,4)==-1
                                Angle_1=atan(V_prec_abs(:,2)./V_prec_abs(:,1)); 
                                Angle_2=atan(V_abs(:,2)./V_abs(:,1)); 
                                angle_measured_big=pi-(Angle_1+Angle_2);
                                angle_measured=Angle_1+Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;  
                            end
                            if V_prec(:,4)==-1 && V(:,4)==1
                                Angle_1=atan(V_prec_abs(:,2)./V_prec_abs(:,1)); 
                                Angle_2=atan(V_abs(:,2)./V_abs(:,1));
                                angle_measured_big=pi-(Angle_1+Angle_2);
                                angle_measured=Angle_1+Angle_2;
                                Degrees_angle1=(angle_measured*180)./pi;  
                            end               
                        if Degrees_angle1==180
                            Degrees_angle1=0;
                        end
                           if Degrees_angle1>90
                           Degrees_angle1=180-Degrees_angle1;
                           end           
        end
dist_tempo=[dist_tempo Degrees_angle1];     
end
end

