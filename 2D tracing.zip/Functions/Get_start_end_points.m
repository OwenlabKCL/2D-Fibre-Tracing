%Input: Fibre id assigned dutring loop, Full_matrix:matrix of x, y, id,
%localisation and tracks, previously ordered by descending track length.
%Output: Matrix_4: Organised matrix, Start and end points for the fibre input.  


function [Start_end_points_fibres,Matrix_4]=Get_start_end_points(Fiber_id,Full_matrix)

Start_end_points_1=[];
Matrix_to_accume=[];
Index_to_take=[];

  for i=1:size(Full_matrix,1)

         Fibre_interest=Full_matrix(i,:);
     
        if size(Fibre_interest{1,1},1)==0
                To_take=i;
                Fiber_start_x=NaN;
                Fiber_start_y=NaN;
                Fiber_end_x=NaN;
                Fiber_end_y=NaN;
                Matrix_sorted=[NaN NaN i NaN NaN];
                Index_to_take=[Index_to_take; To_take];
            
        elseif size(Fibre_interest{1,1},1)~=0
            
                      Matrix_to_sort=cell2mat(Fibre_interest);
                      To_order=Matrix_to_sort;
                      [~, orientation] = max([std(To_order(:,1)),std(To_order(:,2))]);

                          if orientation==1
                               Matrix_sorted=sortrows(To_order, 1);
                          elseif orientation==2
                               Matrix_sorted=sortrows(To_order, 2);
                          end
                                      
                 Matrix_sorted1=unique(Matrix_sorted, 'rows','stable');
                 Fiber_start_x=Matrix_sorted1(1,1);
                 Fiber_start_y=Matrix_sorted1(1,2);
                 Fiber_end_x=Matrix_sorted1(end,1);
                 Fiber_end_y=Matrix_sorted1(end, 2);
        end
        
        Matrix_to_accume=[Matrix_to_accume;Matrix_sorted];
        Start_end_points_1=[Start_end_points_1;Fiber_start_x ,...
        Fiber_start_y, Fiber_end_x,Fiber_end_y];                  
  end
  
%Get the correct start and end points for each given fibre within the loop   
Start_end_points_fibres=Start_end_points_1(Fiber_id, :);
     
x_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,1),[],@(v){v});
x_1(any(cellfun(@isempty,x_1),2),:) = [];
y_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,2),[],@(v){v});
y_1(any(cellfun(@isempty,y_1),2),:) = [];
id_1 = accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,3),[],@(v){v});
id_1(any(cellfun(@isempty,id_1),2),:) = [];
Loc_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,4),[],@(v){v});
Loc_1(any(cellfun(@isempty,Loc_1),2),:) = [];
Track_1=accumarray(Matrix_to_accume(:,3),Matrix_to_accume(:,5),[],@(v){v});
Track_1(any(cellfun(@isempty,Track_1),2),:) = [];

P_with_tracks_after_stitch_sorted1=[x_1, y_1, id_1,Loc_1,Track_1];
P_with_tracks_after_stitch_sorted1 (Index_to_take,:)={[]};
Matrix_4=P_with_tracks_after_stitch_sorted1;

end