%Input : Fibers list - x , y, ID, clock, localisation precision.
%Output: Organised ordered cell array of identified fibres and their
%'Euclidean' lengths. x, y, ID, Track length, Localisation precision. 

function [Matrix_of_origional_tracks]= Get_Fibre_Tracks(fibers_list)
cd(pwd);
Data=fibers_list;

%Delete anything classed as not belonging to a fibre trace.
IDs=Data(:,3);
[n, bin] = histc(IDs, unique(IDs));
single = find(n<=5); 
idx = ismember(bin, single);
Data(idx,:)=[];

if size(Data,1)~=0
    
       Matrix_to_sort = Data;
       IDS_To_Sort=sortrows(Matrix_to_sort,3);
       X = accumarray(IDS_To_Sort(:,3),IDS_To_Sort(:,1),[],@(v){v});
       X(any(cellfun(@isempty,X),2),:) = [];
       Y = accumarray(IDS_To_Sort(:,3),IDS_To_Sort(:,2),[],@(v){v}); 
       Y(any(cellfun(@isempty,Y),2),:) = [];
       IDS=accumarray(IDS_To_Sort(:,3),IDS_To_Sort(:,3),[],@(v){v}); 
       IDS(any(cellfun(@isempty,IDS),2),:) = [];
       Empty_ignore=accumarray(IDS_To_Sort(:,3),IDS_To_Sort(:,4),[],@(v){v});
       Empty_ignore(any(cellfun(@isempty,Empty_ignore),2),:) = [];
       Localisations=accumarray(IDS_To_Sort(:,3),IDS_To_Sort(:,5),[],@(v){v});
       Localisations(any(cellfun(@isempty,Localisations),2),:)=[];
       Matrix=[];
       Matrix=horzcat(X,Y,IDS,Empty_ignore, Localisations); 
             
            %Fill useless 4th column with new ordered IDs
            %Matrix has: x, y, old ID, new ID, localisation uncertainty
            for m=1:size(Matrix, 1)
                Matrix(m,4)={[repmat(m,size(Matrix{m,1},1),1)]};
            end
            %New matrix has: x, y, new ID, localisation uncertainty

       New_matrix=[];
       New_matrix=[Matrix(:,1:2) Matrix(:,4:5)];    
      %Find the track lengths of the traces.
      distance_segment=[];
      All_tracks=[];

        for j=1:size(New_matrix,1)
             Matrix_of_tracks=[];           
             Matrix_x=New_matrix{j,1}; Matrix_y=New_matrix{j,2};
             Matrix_IDS=New_matrix{j,3};
             X_coordinate=[];
             Y_coordinate=[];
             All_Vectors=[];
             distances=[];
             Vector=[];

                  for i=1:size(Matrix_x,1)
                                    Sum_of_distances=[]; 
                                    X_coordinate=Matrix_x(i);
                                    Y_coordinate=Matrix_y(i);
                                    Vector=[X_coordinate;Y_coordinate];
                                    All_Vectors=[All_Vectors, Vector];
                                    d=[];
                                    e=[];
                                    All_distance_segments_per_ID=[];
                               
                                for m=1:size(All_Vectors, 2)-1
                                    d=All_Vectors(1,m+1)-All_Vectors(1,m);
                                    e=All_Vectors(2,m+1)-All_Vectors(2,m);
                                    distance_segment=sqrt(d^2+e^2);
                                    All_distance_segments_per_ID=[All_distance_segments_per_ID;distance_segment];
                                    Sum_of_distances=sum(All_distance_segments_per_ID);
                                end

                  end

          distances=[distances;Sum_of_distances];

          Track_length_per_fiber=repmat(distances,size(Matrix_x,1),1);
          Track_length_per_fiber={Track_length_per_fiber};
          All_tracks=[All_tracks;Track_length_per_fiber];               

        end

         Matrix_of_tracks=[New_matrix All_tracks]; %x,y, ID, localisation and the origional track length. 
         %Switch ordering of Matrix_of_tracks for the next part of code.
         Switch_loc=Matrix_of_tracks(:,4);
         Switch_track=Matrix_of_tracks(:,5);
         Matrix_of_origional_tracks=[];
         Matrix_of_origional_tracks=[Matrix_of_tracks(:,1:3), Switch_track, Switch_loc]; 
         
else     
    Matrix_of_origional_tracks={[]};
    disp 'No fibre tracks have been identified - Abort'
end
end