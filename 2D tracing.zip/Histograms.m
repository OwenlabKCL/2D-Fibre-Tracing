%%%%%%%%%%%%%%%%%%%% Histograms for fibre descriptors %%%%%%%%%%%%%%%%%%%%
MainDirectory='C:\Users\Analysis\Desktop\Fianl tracing codes\RegularGrid binarise\1';
NumberROIS=2;
bin_numfibres=2; % Bin for the number of fibres
bin_lengths=150; % Bin for the fibre lengths
bin_areas=5; % Bin for the enclosed areas
bin_angles=5; % Bin for branch angles
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

number=[];
fibre_lengths=[];
Areas_times_ten_4sqnm=[];
Areas=[];
Angles=[];

for i=1:NumberROIS
    
    cd(MainDirectory);
    foldername=num2str(i);
    cd(fullfile(MainDirectory,foldername));
    %Import variables
    %Number
    colormap Jet 
    L=load('Final_list.mat');
    Final_list=L.Final_list;
    number_per_roi=size(Final_list, 1);
    
    if number_per_roi~=0  
            number=[number;number_per_roi];
            %Lengths
            fibre_lengths_per_roi=[];
            All_lengths=Final_list(:,end);
            for u=1:size(All_lengths,1)
               Tracks=All_lengths{u,1}(1);
               fibre_lengths_per_roi=[fibre_lengths_per_roi;Tracks];
            end
            fibre_lengths=[fibre_lengths;fibre_lengths_per_roi];

            %Areas
            L2=load('Enclosed_areas_nm_squared.mat');
            Areas_per_roi=L2.Area_sq_nm;   
            Areas_times_ten_4sqnm_per_roi=Areas_per_roi./(1e4);
            Areas=[Areas;Areas_per_roi];
            Areas_times_ten_4sqnm=[Areas_times_ten_4sqnm;Areas_times_ten_4sqnm_per_roi];

            %Branch angles
            L3=load('Branch_angles.mat');
            Angles_per_roi=L3.Branch_angles;
            Angles=[Angles;Angles_per_roi];
    end
end

cd(MainDirectory);

if number~=0    
    
        Median_numfibres=mean(number);
        Median_lengths=mean(fibre_lengths);
        Median_areas=mean(Areas);
        Median_areas_norm=mean(Areas_times_ten_4sqnm);
        Median_angles=mean(Angles);

        %range for hist axis
        min_nfibres=min(number)-bin_numfibres;
        max_nfibres=max(number)+bin_numfibres;
        min_lengths=min(fibre_lengths)-bin_lengths;
        max_lengths=max(fibre_lengths)+bin_lengths;
        min_areas=min(Areas)-bin_areas;
        max_areas=max(Areas)+bin_areas;
        min_areas_norm=min(Areas_times_ten_4sqnm)-bin_areas;
        max_areas_norm=max(Areas_times_ten_4sqnm)+bin_areas;
        min_angles=min(Angles)-bin_angles;
        max_angles=max(Angles)+bin_angles;


        %Figures
        h1 = hist(number,[min_nfibres:bin_numfibres:max_nfibres]);
        maxhglobal=max(h1)+10;
        figure1 = figure('Color',[1 1 1]);
        colormap('hsv');
        axes1 = axes('Parent',figure1,'YGrid','on','XGrid','on','FontSize',30);
        box(axes1,'on');
        grid(axes1,'on');
        hold(axes1,'on');
        bar1=bar([min_nfibres:bin_numfibres:max_nfibres], h1', 'BarWidth',1);
        set(bar1(1),'FaceColor','b');
        xlabel('Number of detected fibres')
        ylabel('Count')
        hold on
        axis square
        hline = line('XData', [Median_numfibres Median_numfibres], 'YData', [0 maxhglobal], 'LineStyle', '--','LineWidth', 2, 'color', 'r');
        legend('Detected','Median','location','northeast')
        set(gca, 'fontsize',40)
        set(gcf, 'Position', get(0,'Screensize'));
        grid on
        saveas(gcf,'Number_fibres.fig')
        close

        h1 = hist(fibre_lengths,[min_lengths:bin_lengths:max_lengths]);
        maxhglobal=max(h1)+10;
        figure2 = figure('Color',[1 1 1]);
        colormap('hsv');
        axes1 = axes('Parent',figure2,'YGrid','on','XGrid','on','FontSize',30);
        box(axes1,'on');
        grid(axes1,'on');
        hold(axes1,'on');
        bar1=bar([min_lengths:bin_lengths:max_lengths], h1', 'BarWidth',1);
        set(bar1(1),'FaceColor','b');
        xlabel('Fibre length (nm)')
        ylabel('Count')
        hold on
        axis square
        hline = line('XData', [Median_lengths Median_lengths], 'YData', [0 maxhglobal], 'LineStyle', '--','LineWidth', 2, 'color','r');
        legend('Detected','Median','location','northeast')
        set(gca, 'fontsize',40)
        set(gcf, 'Position', get(0,'Screensize'));
        grid on
        saveas(gcf,'Fibre_lengths.fig')
        close

        h1 = hist(Areas_times_ten_4sqnm,[min_areas_norm:bin_areas:max_areas_norm]);
        maxhglobal=max(h1)+10;
        figure3 = figure('Color',[1 1 1]);
        colormap('hsv');
        axes1 = axes('Parent',figure3,'YGrid','on','XGrid','on','FontSize',30);
        box(axes1,'on');
        grid(axes1,'on');
        hold(axes1,'on');
        bar1=bar([min_areas_norm:bin_areas:max_areas_norm], h1, 'BarWidth',1);
        set(bar1(1),'FaceColor','b');
        xlabel('Enclosed Areas x10{^4} nm{^2}')
        ylabel('Count')
        hold on
        axis square
        hline = line('XData', [Median_areas_norm Median_areas_norm], 'YData', [0 maxhglobal], 'LineStyle', '--','LineWidth', 2, 'color', 'r');
        legend('Detected','Median','location','northeast')
        set(gca, 'fontsize',40)
        set(gcf, 'Position', get(0,'Screensize'));
        grid on
        saveas(gcf,'Areas.fig')
        close

        h1 = hist(Angles,[min_angles:bin_angles:max_angles]);
        maxhglobal=max(h1)+10;
        figure4 = figure('Color',[1 1 1]);
        colormap('hsv');
        axes1 = axes('Parent',figure4,'YGrid','on','XGrid','on','FontSize',30);
        box(axes1,'on');
        grid(axes1,'on');
        hold(axes1,'on');
        bar1=bar([min_angles:bin_angles:max_angles], h1, 'BarWidth',1);
        set(bar1(1),'FaceColor','b', 'EdgeColor', 'k');
        xlabel('Branch Angles ({\circ})')
        ylabel('Count')
        hold on
        axis square
        hline = line('XData', [Median_angles Median_angles], 'YData', [0 maxhglobal], 'LineStyle', '--','LineWidth', 2, 'color', 'r');
        legend('Detected','Median','location','northeast')
        set(gca, 'fontsize',40)
        set(gcf, 'Position', get(0,'Screensize'));
        grid on
        saveas(gcf,'Branch_angles.fig')
        close

elseif number==0
    disp ('No detected fibres for this data set...')
end

